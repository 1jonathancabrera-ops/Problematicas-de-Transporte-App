namespace TransporteMAUI.Navigation;

/// <summary>
/// Nombres de ruta de Shell, centralizados acá para que los ViewModels (en esta librería,
/// sin depender de MAUI) y el registro de rutas de <c>AppShell</c> (en la cabecera MAUI)
/// usen exactamente el mismo string sin que los ViewModels necesiten referenciar los
/// tipos de página (que viven en el proyecto de UI).
/// </summary>
public static class Routes
{
    public const string MainPage = "MainPage";
    public const string NewProjectGalleryPage = "NewProjectGalleryPage";
    public const string NewProblemPage = "NewProblemPage";
    public const string SolutionPage = "SolutionPage";
    public const string HelpPage = "HelpPage";

    /// <summary>Ruta especial de Shell para volver a la página anterior en la pila.</summary>
    public const string Back = "..";
}
