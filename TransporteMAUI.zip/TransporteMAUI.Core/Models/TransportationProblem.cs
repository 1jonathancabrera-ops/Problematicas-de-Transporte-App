namespace TransporteMAUI.Models;

/// <summary>
/// Indica si el problema requirió balanceo y de qué tipo.
/// </summary>
public enum FictitiousType
{
    None,
    Origin,     // Oferta ficticia (demanda > oferta)
    Destination // Demanda ficticia (oferta > demanda)
}

/// <summary>
/// Representa un problema de transporte tal como lo ingresa el usuario:
/// matriz de costos, ofertas y demandas, ya sea balanceado o no.
/// Es el objeto de entrada de los tres algoritmos (Northwest, LeastCost, Vogel).
/// </summary>
public class TransportationProblem
{
    /// <summary>Costos originales ingresados por el usuario, sin ficticios. Costs[origen][destino].</summary>
    public double[][] Costs { get; set; }

    /// <summary>Ofertas originales por origen.</summary>
    public double[] Supply { get; set; }

    /// <summary>Demandas originales por destino.</summary>
    public double[] Demand { get; set; }

    public int OriginCount => Supply.Length;
    public int DestinationCount => Demand.Length;

    public TransportationProblem(double[][] costs, double[] supply, double[] demand)
    {
        Costs = costs;
        Supply = supply;
        Demand = demand;
    }

    public double TotalSupply => Supply.Sum();
    public double TotalDemand => Demand.Sum();

    public bool IsBalanced => Math.Abs(TotalSupply - TotalDemand) < 0.0000001;

    /// <summary>
    /// Diferencia absoluta entre oferta y demanda totales (0 si está balanceado).
    /// </summary>
    public double Difference => Math.Abs(TotalSupply - TotalDemand);

    /// <summary>
    /// Determina qué tipo de fila/columna ficticia hace falta agregar, si corresponde.
    /// </summary>
    public FictitiousType RequiredFictitious
    {
        get
        {
            if (IsBalanced) return FictitiousType.None;
            // Oferta > Demanda  -> sobra oferta -> hace falta un destino (demanda) ficticio
            // Demanda > Oferta  -> sobra demanda -> hace falta un origen (oferta) ficticio
            return TotalSupply > TotalDemand ? FictitiousType.Destination : FictitiousType.Origin;
        }
    }

    /// <summary>
    /// Devuelve una copia balanceada del problema: si hace falta, agrega la fila u columna
    /// ficticia (costo 0) correspondiente. Si ya está balanceado, devuelve una copia idéntica.
    /// Centraliza la lógica de balanceo para que los tres algoritmos la compartan.
    /// </summary>
    public BalancedProblem GetBalanced()
    {
        var type = RequiredFictitious;
        int rows = OriginCount;
        int cols = DestinationCount;

        var supply = (double[])Supply.Clone();
        var demand = (double[])Demand.Clone();

        double[][] costs;

        if (type == FictitiousType.None)
        {
            costs = Costs.Select(row => (double[])row.Clone()).ToArray();
            return new BalancedProblem(costs, supply, demand, FictitiousType.None, 0);
        }

        double diff = Difference;

        if (type == FictitiousType.Destination)
        {
            // Se agrega una columna (destino ficticio) con costo 0 en todas las filas.
            cols++;
            costs = new double[rows][];
            for (int i = 0; i < rows; i++)
            {
                costs[i] = new double[cols];
                Array.Copy(Costs[i], costs[i], DestinationCount);
                costs[i][cols - 1] = 0;
            }
            demand = demand.Append(diff).ToArray();
        }
        else
        {
            // Se agrega una fila (origen ficticio) con costo 0 en todas las columnas.
            rows++;
            costs = new double[rows][];
            for (int i = 0; i < OriginCount; i++)
                costs[i] = (double[])Costs[i].Clone();
            costs[rows - 1] = new double[cols];
            supply = supply.Append(diff).ToArray();
        }

        return new BalancedProblem(costs, supply, demand, type, diff);
    }
}

/// <summary>
/// Versión ya balanceada de un problema (con la fila/columna ficticia incorporada si hacía falta).
/// Es lo que reciben internamente los algoritmos de resolución.
/// </summary>
public class BalancedProblem
{
    public double[][] Costs { get; }
    public double[] Supply { get; }
    public double[] Demand { get; }
    public FictitiousType FictitiousType { get; }
    public double FictitiousAmount { get; }

    public int Rows => Supply.Length;
    public int Cols => Demand.Length;

    public BalancedProblem(double[][] costs, double[] supply, double[] demand, FictitiousType fictitiousType, double fictitiousAmount)
    {
        Costs = costs;
        Supply = supply;
        Demand = demand;
        FictitiousType = fictitiousType;
        FictitiousAmount = fictitiousAmount;
    }

    /// <summary>True si la fila con índice <paramref name="row"/> es la fila ficticia agregada.</summary>
    public bool IsFictitiousRow(int row) => FictitiousType == FictitiousType.Origin && row == Rows - 1;

    /// <summary>True si la columna con índice <paramref name="col"/> es la columna ficticia agregada.</summary>
    public bool IsFictitiousCol(int col) => FictitiousType == FictitiousType.Destination && col == Cols - 1;
}
