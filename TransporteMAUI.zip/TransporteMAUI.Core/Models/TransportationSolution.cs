namespace TransporteMAUI.Models;

/// <summary>
/// Resultado de aplicar un método de resolución (Esquina Noroeste, Menor Costo o Vogel)
/// sobre un <see cref="TransportationProblem"/>.
/// </summary>
public class TransportationSolution
{
    public string MethodName { get; init; } = string.Empty;

    public int Rows { get; init; }
    public int Cols { get; init; }

    /// <summary>Celdas de la tabla resuelta (fila x columna), incluyendo ficticios si los hubo.</summary>
    public List<CellAssignment> Cells { get; init; } = new();

    public bool WasBalancedOriginally { get; init; }
    public FictitiousType FictitiousType { get; init; }
    public double FictitiousAmount { get; init; }

    /// <summary>Término a término de la expresión del costo, ej. "(20 × 5)".</summary>
    public List<string> CostExpressionTerms { get; init; } = new();

    public double TotalCost { get; init; }

    /// <summary>
    /// Historial de penalizaciones por iteración, una entrada por cada ronda de cálculo
    /// de penalizaciones. Solo lo completa <see cref="TransporteMAUI.Algorithms.VogelMethod"/>;
    /// para Esquina Noroeste y Menor Costo queda en null.
    /// </summary>
    public List<VogelIterationSnapshot>? VogelIterations { get; init; }

    public CellAssignment GetCell(int row, int col) => Cells.First(c => c.Row == row && c.Col == col);

    public double SupplyRowTotal(int row) => Cells.Where(c => c.Row == row).Sum(c => c.Quantity);
    public double DemandColTotal(int col) => Cells.Where(c => c.Col == col).Sum(c => c.Quantity);
}
