namespace TransporteMAUI.Models;

/// <summary>
/// Foto de una iteración del método de Vogel: la penalización de cada fila/columna en
/// ese momento (null si esa fila/columna ya estaba eliminada antes de esta iteración),
/// y qué fila y/o columna quedó eliminada al final de esta iteración. Permite reconstruir
/// en la UI la tabla de trabajo clásica con las columnas "Penalización 1", "Penalización 2", etc.
/// </summary>
public class VogelIterationSnapshot
{
    /// <summary>Penalización de cada fila en esta iteración; null si la fila ya no estaba activa.</summary>
    public double?[] RowPenalties { get; init; } = Array.Empty<double?>();

    /// <summary>Penalización de cada columna en esta iteración; null si la columna ya no estaba activa.</summary>
    public double?[] ColPenalties { get; init; } = Array.Empty<double?>();

    /// <summary>Índice de la fila que quedó eliminada al terminar esta iteración, o null si no se eliminó ninguna.</summary>
    public int? EliminatedRow { get; init; }

    /// <summary>Índice de la columna que quedó eliminada al terminar esta iteración, o null si no se eliminó ninguna.</summary>
    public int? EliminatedCol { get; init; }
}
