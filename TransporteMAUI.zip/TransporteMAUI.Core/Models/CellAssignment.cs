namespace TransporteMAUI.Models;

/// <summary>
/// Representa una celda de la tabla resuelta: fila, columna, costo, cantidad asignada
/// y si corresponde a una fila/columna ficticia (para resaltarla en la UI).
/// </summary>
public class CellAssignment
{
    public int Row { get; init; }
    public int Col { get; init; }
    public double Cost { get; init; }
    public double Quantity { get; init; }
    public bool IsFictitiousRow { get; init; }
    public bool IsFictitiousCol { get; init; }

    public bool IsUsed => Quantity > 0;
    public bool IsFictitious => IsFictitiousRow || IsFictitiousCol;

    public string Display => $"{Quantity:0.##} | {Cost:0.##}";
}
