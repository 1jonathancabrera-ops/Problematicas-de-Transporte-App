namespace TransporteMAUI.Models;

/// <summary>
/// Representa un "proyecto" completo: el problema ingresado por el usuario más
/// (opcionalmente) el método elegido y la solución obtenida. Es la unidad que se
/// guarda/abre en disco como archivo .json propio de la aplicación.
/// </summary>
public class TransportationProject
{
    public string Name { get; set; } = "Nuevo proyecto";
    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime LastModified { get; set; } = DateTime.Now;

    public int OriginCount { get; set; }
    public int DestinationCount { get; set; }

    public double[][] Costs { get; set; } = Array.Empty<double[]>();
    public double[] Supply { get; set; } = Array.Empty<double>();
    public double[] Demand { get; set; } = Array.Empty<double>();

    /// <summary>Nombre del método usado la última vez que se resolvió (Esquina Noroeste, Menor Costo o Vogel), o null si no se resolvió aún.</summary>
    public string? MethodUsed { get; set; }

    public bool WasSolved { get; set; }

    /// <summary>
    /// Convierte los datos crudos del proyecto en un TransportationProblem listo
    /// para pasarle a un algoritmo.
    /// </summary>
    public TransportationProblem ToProblem() => new(Costs, Supply, Demand);

    public static TransportationProject FromProblem(TransportationProblem problem, string name)
    {
        return new TransportationProject
        {
            Name = name,
            OriginCount = problem.OriginCount,
            DestinationCount = problem.DestinationCount,
            Costs = problem.Costs,
            Supply = problem.Supply,
            Demand = problem.Demand
        };
    }
}
