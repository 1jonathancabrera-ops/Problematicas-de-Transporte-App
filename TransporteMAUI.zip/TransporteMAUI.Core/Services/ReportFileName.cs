namespace TransporteMAUI.Services;

/// <summary>Arma el nombre del archivo PDF del informe (lo usan tanto Inicio como Resultados).</summary>
public static class ReportFileName
{
    public static string For(string projectName)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var safe = new string(projectName.Where(c => !invalid.Contains(c)).ToArray());
        return $"Informe_{safe}_{DateTime.Now:yyyyMMdd_HHmmss}.pdf";
    }
}
