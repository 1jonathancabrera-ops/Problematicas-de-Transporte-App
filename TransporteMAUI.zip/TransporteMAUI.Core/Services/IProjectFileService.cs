using TransporteMAUI.Models;

namespace TransporteMAUI.Services;

/// <summary>Guarda y abre proyectos de transporte. Ver implementación concreta en el proyecto de UI.</summary>
public interface IProjectFileService
{
    /// <summary>Abre el diálogo nativo "Guardar como". Devuelve la ruta final, o null si se canceló.</summary>
    Task<string?> SaveAsAsync(TransportationProject project);

    /// <summary>Ofrece compartir/exportar un archivo ya guardado usando el diálogo nativo del sistema.</summary>
    Task ShareAsync(string filePath, string title = "Compartir proyecto");

    /// <summary>Abre un proyecto eligiendo el archivo con el selector nativo. Devuelve null si se canceló.</summary>
    Task<TransportationProject?> OpenAsync();
}
