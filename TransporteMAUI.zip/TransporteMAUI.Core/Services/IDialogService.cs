namespace TransporteMAUI.Services;

/// <summary>
/// Abstrae los diálogos nativos (hoy implementados con DisplayAlertAsync de MAUI) para
/// que los ViewModels puedan testearse sin necesitar una aplicación MAUI real corriendo.
/// </summary>
public interface IDialogService
{
    Task AlertAsync(string title, string message, string accept = "Aceptar");

    Task<bool> ConfirmAsync(string title, string message, string accept, string cancel);
}
