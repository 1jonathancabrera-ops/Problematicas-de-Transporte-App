namespace TransporteMAUI.Services;

/// <summary>
/// Equivalente propio de <c>Microsoft.Maui.Controls.IQueryAttributable</c> (ese sí es un
/// tipo de MAUI Controls, no se puede usar acá). La página real que recibe la navegación
/// implementa <c>IQueryAttributable</c> de MAUI y reenvía la llamada al ViewModel a través
/// de esta interfaz, para que el ViewModel pueda seguir viviendo en esta librería sin
/// depender de MAUI Controls.
/// </summary>
public interface IQueryParameterReceiver
{
    void ApplyQueryAttributes(IDictionary<string, object> query);
}
