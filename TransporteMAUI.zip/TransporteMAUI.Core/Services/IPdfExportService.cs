using TransporteMAUI.Models;

namespace TransporteMAUI.Services;

/// <summary>Genera el informe PDF de un problema de transporte. Ver implementación concreta en el proyecto de UI.</summary>
public interface IPdfExportService
{
    /// <summary>
    /// Genera el PDF con el nombre de archivo sugerido (la implementación decide la carpeta
    /// final apropiada para la plataforma) y devuelve la ruta completa resultante.
    /// </summary>
    /// <param name="rowLabels">
    /// Etiquetas de fila a usar en la tabla de solución (ej. si el usuario las renombró en la
    /// pantalla de resultados), en el mismo orden que las filas. Si es null, se usan "O1", "O2"...
    /// </param>
    /// <param name="colLabels">Igual que <paramref name="rowLabels"/> pero para las columnas ("D1", "D2"...).</param>
    string Export(TransportationProject project, TransportationSolution? solution, string fileName,
        string[]? rowLabels = null, string[]? colLabels = null);
}
