namespace TransporteMAUI.Services;

/// <summary>
/// Abstrae la navegación (hoy implementada con Shell de MAUI) para que los ViewModels
/// puedan testearse sin necesitar una aplicación MAUI real corriendo.
/// </summary>
public interface INavigationService
{
    Task GoToAsync(string route);
    Task GoToAsync(string route, IDictionary<string, object> parameters);
}
