using TransporteMAUI.Models;

namespace TransporteMAUI.Algorithms;

/// <summary>
/// Método de aproximación de Vogel (VAM). En cada iteración calcula, para cada fila y
/// columna activa, la penalización (diferencia entre los dos costos más bajos disponibles).
/// Selecciona la fila/columna de mayor penalización y, dentro de ella, la celda de menor
/// costo disponible; asigna allí el máximo posible y elimina la fila o columna que quedó
/// satisfecha, repitiendo hasta terminar.
///
/// Reglas de empate documentadas:
///  - Empate de penalizaciones entre varias filas/columnas: se elige, en este orden,
///    primero la fila de menor índice y luego la columna de menor índice (se recorren
///    primero todas las filas y después todas las columnas).
///  - Empate de costo mínimo dentro de la fila/columna elegida: se elige la celda con
///    menor índice de fila y luego de columna.
///  - Cuando una asignación deja simultáneamente en cero la oferta de una fila y la
///    demanda de una columna, se elimina solo la fila (se mantiene la columna con
///    demanda residual 0), para evitar quitar dos restricciones en el mismo paso.
/// </summary>
public class VogelMethod : ITransportationMethod
{
    public string Name => "Vogel";

    public string Icon => "🎯";

    public string Description =>
        "Utiliza penalizaciones (diferencia entre los dos menores costos de cada fila/columna) " +
        "para elegir dónde asignar en cada paso, obteniendo generalmente una solución inicial " +
        "más cercana al óptimo que los otros dos métodos.";

    public TransportationSolution Solve(TransportationProblem problem)
    {
        var bp = problem.GetBalanced();
        var supply = (double[])bp.Supply.Clone();
        var demand = (double[])bp.Demand.Clone();

        var assignment = new double[bp.Rows, bp.Cols];
        var iterations = new List<VogelIterationSnapshot>();

        bool[] rowActive = new bool[bp.Rows];
        bool[] colActive = new bool[bp.Cols];
        for (int i = 0; i < bp.Rows; i++) rowActive[i] = supply[i] > 0.0000001;
        for (int j = 0; j < bp.Cols; j++) colActive[j] = demand[j] > 0.0000001;

        int activeRows = rowActive.Count(x => x);
        int activeCols = colActive.Count(x => x);

        while (activeRows > 0 && activeCols > 0)
        {
            // Caso trivial: si solo queda una fila o una columna activa, se asigna
            // directamente todo lo que reste, celda por celda de menor costo. No se
            // registra una nueva iteración de penalización para este paso final (tal
            // como se ve en la tabla de trabajo clásica del método).
            if (activeRows == 1 || activeCols == 1)
            {
                AsignarRestante(bp, supply, demand, rowActive, colActive, assignment);
                break;
            }

            // Se calcula la penalización de cada fila/columula ACTIVA una sola vez por
            // iteración, y se reutiliza tanto para elegir dónde asignar como para el
            // snapshot que arma la tabla de trabajo (columnas "Penalización 1, 2, 3...").
            var rowPenalties = new double?[bp.Rows];
            var colPenalties = new double?[bp.Cols];

            for (int i = 0; i < bp.Rows; i++)
                if (rowActive[i]) rowPenalties[i] = CalcularPenalizacionFila(bp, i, colActive);

            for (int j = 0; j < bp.Cols; j++)
                if (colActive[j]) colPenalties[j] = CalcularPenalizacionColumna(bp, j, rowActive);

            double mejorPenalizacion = -1;
            bool esFila = true;
            int mejorIndice = -1;

            // Se recorren primero todas las filas y después todas las columnas: en caso
            // de empate de penalización, queda la de menor índice encontrada primero.
            for (int i = 0; i < bp.Rows; i++)
            {
                if (rowPenalties[i] is double rp && rp > mejorPenalizacion)
                {
                    mejorPenalizacion = rp;
                    esFila = true;
                    mejorIndice = i;
                }
            }
            for (int j = 0; j < bp.Cols; j++)
            {
                if (colPenalties[j] is double cp && cp > mejorPenalizacion)
                {
                    mejorPenalizacion = cp;
                    esFila = false;
                    mejorIndice = j;
                }
            }

            // Dentro de la fila/columna elegida, buscar el menor costo disponible.
            int filaSel, colSel;
            if (esFila)
            {
                filaSel = mejorIndice;
                colSel = MenorCostoEnFila(bp, mejorIndice, colActive);
            }
            else
            {
                colSel = mejorIndice;
                filaSel = MenorCostoEnColumna(bp, mejorIndice, rowActive);
            }

            double cantidad = Math.Min(supply[filaSel], demand[colSel]);
            assignment[filaSel, colSel] = cantidad;
            supply[filaSel] -= cantidad;
            demand[colSel] -= cantidad;

            bool filaSatisfecha = supply[filaSel] <= 0.0000001;
            bool colSatisfecha = demand[colSel] <= 0.0000001;

            int? eliminatedRow = null;
            int? eliminatedCol = null;

            if (filaSatisfecha && colSatisfecha)
            {
                // Solo se elimina una restricción por paso (ver regla de empate documentada).
                rowActive[filaSel] = false;
                activeRows--;
                eliminatedRow = filaSel;
            }
            else if (filaSatisfecha)
            {
                rowActive[filaSel] = false;
                activeRows--;
                eliminatedRow = filaSel;
            }
            else if (colSatisfecha)
            {
                colActive[colSel] = false;
                activeCols--;
                eliminatedCol = colSel;
            }

            iterations.Add(new VogelIterationSnapshot
            {
                RowPenalties = rowPenalties,
                ColPenalties = colPenalties,
                EliminatedRow = eliminatedRow,
                EliminatedCol = eliminatedCol
            });
        }

        return SolutionBuilder.Build(Name, bp, assignment, problem.IsBalanced, iterations);
    }

    private static double CalcularPenalizacionFila(BalancedProblem bp, int row, bool[] colActive)
    {
        var costosDisponibles = new List<double>();
        for (int j = 0; j < bp.Cols; j++)
            if (colActive[j]) costosDisponibles.Add(bp.Costs[row][j]);

        costosDisponibles.Sort();
        if (costosDisponibles.Count == 0) return -1;
        if (costosDisponibles.Count == 1) return costosDisponibles[0];
        return costosDisponibles[1] - costosDisponibles[0];
    }

    private static double CalcularPenalizacionColumna(BalancedProblem bp, int col, bool[] rowActive)
    {
        var costosDisponibles = new List<double>();
        for (int i = 0; i < bp.Rows; i++)
            if (rowActive[i]) costosDisponibles.Add(bp.Costs[i][col]);

        costosDisponibles.Sort();
        if (costosDisponibles.Count == 0) return -1;
        if (costosDisponibles.Count == 1) return costosDisponibles[0];
        return costosDisponibles[1] - costosDisponibles[0];
    }

    private static int MenorCostoEnFila(BalancedProblem bp, int row, bool[] colActive)
    {
        double min = double.PositiveInfinity;
        int mejorCol = -1;
        for (int j = 0; j < bp.Cols; j++)
        {
            if (!colActive[j]) continue;
            if (bp.Costs[row][j] < min)
            {
                min = bp.Costs[row][j];
                mejorCol = j;
            }
        }
        return mejorCol;
    }

    private static int MenorCostoEnColumna(BalancedProblem bp, int col, bool[] rowActive)
    {
        double min = double.PositiveInfinity;
        int mejorFila = -1;
        for (int i = 0; i < bp.Rows; i++)
        {
            if (!rowActive[i]) continue;
            if (bp.Costs[i][col] < min)
            {
                min = bp.Costs[i][col];
                mejorFila = i;
            }
        }
        return mejorFila;
    }

    /// <summary>
    /// Cuando ya solo queda una fila (o una columna) activa, no hace falta seguir
    /// calculando penalizaciones: se asignan las celdas restantes en orden de menor costo.
    /// </summary>
    private static void AsignarRestante(BalancedProblem bp, double[] supply, double[] demand,
        bool[] rowActive, bool[] colActive, double[,] assignment)
    {
        var celdas = new List<(int i, int j, double costo)>();
        for (int i = 0; i < bp.Rows; i++)
        {
            if (!rowActive[i]) continue;
            for (int j = 0; j < bp.Cols; j++)
            {
                if (!colActive[j]) continue;
                celdas.Add((i, j, bp.Costs[i][j]));
            }
        }

        foreach (var (i, j, _) in celdas.OrderBy(c => c.costo).ThenBy(c => c.i).ThenBy(c => c.j))
        {
            if (supply[i] <= 0.0000001 || demand[j] <= 0.0000001) continue;
            double cantidad = Math.Min(supply[i], demand[j]);
            assignment[i, j] += cantidad;
            supply[i] -= cantidad;
            demand[j] -= cantidad;
        }
    }
}
