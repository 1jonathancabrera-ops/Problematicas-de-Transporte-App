using TransporteMAUI.Models;

namespace TransporteMAUI.Algorithms;

/// <summary>
/// Método de la Esquina Noroeste: comienza en la celda superior izquierda (0,0) y
/// asigna min(oferta, demanda) disponibles, avanzando en fila o columna según cuál
/// de las dos se agote primero. No tiene en cuenta el costo.
/// </summary>
public class NorthwestCornerMethod : ITransportationMethod
{
    public string Name => "Esquina Noroeste";

    public string Icon => "🧭";

    public string Description =>
        "Obtiene una solución inicial comenzando desde la esquina superior izquierda de la tabla " +
        "y avanzando fila por fila o columna por columna sin considerar el costo.";

    public TransportationSolution Solve(TransportationProblem problem)
    {
        var bp = problem.GetBalanced();
        var supply = (double[])bp.Supply.Clone();
        var demand = (double[])bp.Demand.Clone();

        var assignment = new double[bp.Rows, bp.Cols];

        int i = 0, j = 0;
        while (i < bp.Rows && j < bp.Cols)
        {
            double cantidad = Math.Min(supply[i], demand[j]);
            assignment[i, j] = cantidad;
            supply[i] -= cantidad;
            demand[j] -= cantidad;

            // Regla original conservada: si la oferta de la fila actual llegó a 0,
            // avanzamos de fila; si no (y por lo tanto se agotó la demanda), avanzamos de columna.
            // Caso especial: si ambas llegan a 0 a la vez (última celda), el bucle debe terminar
            // igual sin intentar asignar una fila/columna inexistente.
            bool supplyDone = supply[i] <= 0.0000001;
            bool demandDone = demand[j] <= 0.0000001;

            if (supplyDone && demandDone)
            {
                // Avanza ambos; si era la última celda el while termina solo.
                i++;
                j++;
            }
            else if (supplyDone)
            {
                i++;
            }
            else
            {
                j++;
            }
        }

        return SolutionBuilder.Build(Name, bp, assignment, problem.IsBalanced);
    }
}
