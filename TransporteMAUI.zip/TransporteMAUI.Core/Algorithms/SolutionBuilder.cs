using TransporteMAUI.Models;

namespace TransporteMAUI.Algorithms;

/// <summary>
/// Toma una matriz de asignaciones ya calculada por cualquiera de los tres métodos
/// y arma el objeto <see cref="TransportationSolution"/> (celdas, expresión de costo,
/// costo total, marcado de ficticios). Evita repetir esta lógica en cada algoritmo.
/// </summary>
internal static class SolutionBuilder
{
    public static TransportationSolution Build(string methodName, BalancedProblem bp, double[,] assignment,
        bool wasBalancedOriginally, List<VogelIterationSnapshot>? vogelIterations = null)
    {
        var cells = new List<CellAssignment>();
        var terms = new List<string>();
        double total = 0;

        for (int i = 0; i < bp.Rows; i++)
        {
            for (int j = 0; j < bp.Cols; j++)
            {
                double qty = assignment[i, j];
                double cost = bp.Costs[i][j];

                cells.Add(new CellAssignment
                {
                    Row = i,
                    Col = j,
                    Quantity = qty,
                    Cost = cost,
                    IsFictitiousRow = bp.IsFictitiousRow(i),
                    IsFictitiousCol = bp.IsFictitiousCol(j)
                });

                if (qty > 0)
                {
                    terms.Add($"({qty:0.##} × {cost:0.##})");
                    total += qty * cost;
                }
            }
        }

        return new TransportationSolution
        {
            MethodName = methodName,
            Rows = bp.Rows,
            Cols = bp.Cols,
            Cells = cells,
            WasBalancedOriginally = wasBalancedOriginally,
            FictitiousType = bp.FictitiousType,
            FictitiousAmount = bp.FictitiousAmount,
            CostExpressionTerms = terms,
            TotalCost = total,
            VogelIterations = vogelIterations
        };
    }
}
