using TransporteMAUI.Models;

namespace TransporteMAUI.Algorithms;

/// <summary>
/// Estrategia común para los algoritmos de solución inicial del problema de transporte.
/// Permite que la interfaz gráfica sea idéntica sin importar el método elegido, y que
/// se agreguen nuevos métodos en el futuro sin tocar el resto de la aplicación.
/// </summary>
public interface ITransportationMethod
{
    /// <summary>Nombre para mostrar en la interfaz, ej. "Método de la Esquina Noroeste".</summary>
    string Name { get; }

    /// <summary>Descripción breve orientada a estudiantes, para la galería de plantillas.</summary>
    string Description { get; }

    /// <summary>Emoji que identifica al método en la galería de plantillas.</summary>
    string Icon { get; }

    /// <summary>Resuelve el problema (balanceándolo primero si hace falta) y devuelve la solución inicial.</summary>
    TransportationSolution Solve(TransportationProblem problem);
}
