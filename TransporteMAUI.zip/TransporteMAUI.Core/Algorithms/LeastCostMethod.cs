using TransporteMAUI.Models;

namespace TransporteMAUI.Algorithms;

/// <summary>
/// Método de Menor Costo: en cada paso busca, entre las celdas con oferta y demanda
/// disponibles, la de menor costo, y asigna allí el máximo posible. Repite hasta
/// satisfacer todas las ofertas y demandas.
/// Regla de empate (documentada): si dos o más celdas comparten el costo mínimo,
/// se elige la que aparece primero recorriendo por fila y luego por columna
/// (menor índice de fila; en caso de igualdad, menor índice de columna).
/// </summary>
public class LeastCostMethod : ITransportationMethod
{
    public string Name => "Menor Costo";

    public string Icon => "💰";

    public string Description =>
        "Realiza asignaciones comenzando por las celdas de menor costo disponible, " +
        "repitiendo el proceso hasta satisfacer todas las ofertas y demandas.";

    public TransportationSolution Solve(TransportationProblem problem)
    {
        var bp = problem.GetBalanced();
        var supply = (double[])bp.Supply.Clone();
        var demand = (double[])bp.Demand.Clone();

        var assignment = new double[bp.Rows, bp.Cols];

        while (true)
        {
            double minimo = double.PositiveInfinity;
            int filaMin = -1, colMin = -1;

            for (int i = 0; i < bp.Rows; i++)
            {
                if (supply[i] <= 0.0000001) continue;
                for (int j = 0; j < bp.Cols; j++)
                {
                    if (demand[j] <= 0.0000001) continue;

                    // Empate: solo reemplaza si es estrictamente menor, así se conserva
                    // la primera celda encontrada (menor fila, luego menor columna).
                    if (bp.Costs[i][j] < minimo)
                    {
                        minimo = bp.Costs[i][j];
                        filaMin = i;
                        colMin = j;
                    }
                }
            }

            if (filaMin == -1) break; // no quedan celdas con oferta y demanda disponibles

            double cantidad = Math.Min(supply[filaMin], demand[colMin]);
            assignment[filaMin, colMin] = cantidad;
            supply[filaMin] -= cantidad;
            demand[colMin] -= cantidad;
        }

        return SolutionBuilder.Build(Name, bp, assignment, problem.IsBalanced);
    }
}
