using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using TransporteMAUI.Algorithms;
using TransporteMAUI.Models;
using TransporteMAUI.Navigation;
using TransporteMAUI.Services;

namespace TransporteMAUI.ViewModels;

/// <summary>
/// ViewModel de la pantalla principal (hub tipo Office). Además de gobernar la pantalla
/// de inicio, funciona como estado compartido de "proyecto actual" y "solución actual"
/// para que el resto de los ViewModels puedan leerlo/escribirlo sin acoplarse entre sí.
/// Se registra como singleton en MauiProgram.
/// </summary>
public partial class MainViewModel : ObservableObject
{
    private readonly IProjectFileService _projectFileService;
    private readonly IPdfExportService _pdfExportService;
    private readonly INavigationService _navigation;
    private readonly IDialogService _dialogs;

    public IEnumerable<ITransportationMethod> Methods { get; }

    /// <summary>Proyecto que se está editando/resolviendo actualmente (null si no se creó ninguno todavía).</summary>
    [ObservableProperty]
    private TransportationProject? currentProject;

    /// <summary>Última solución calculada para el proyecto actual (null si aún no se resolvió).</summary>
    [ObservableProperty]
    private TransportationSolution? currentSolution;

    [ObservableProperty]
    private string statusMessage = "Bienvenido. Creá un nuevo problema o abrí uno existente para comenzar.";

    /// <summary>
    /// True si la solución actual viene de reabrir un proyecto que ya estaba resuelto
    /// (se recalculó sola al abrir); false si se acaba de resolver de cero. La pantalla
    /// de resultados usa esto para decidir si mostrar el costo total ya revelado o detrás
    /// del botón "Mostrar costo total".
    /// </summary>
    public bool SolutionWasPreloaded { get; set; }

    public bool HasProject => CurrentProject is not null;

    public MainViewModel(IEnumerable<ITransportationMethod> methods, IProjectFileService projectFileService,
        IPdfExportService pdfExportService, INavigationService navigation, IDialogService dialogs)
    {
        Methods = methods;
        _projectFileService = projectFileService;
        _pdfExportService = pdfExportService;
        _navigation = navigation;
        _dialogs = dialogs;
    }

    partial void OnCurrentProjectChanged(TransportationProject? value)
    {
        OnPropertyChanged(nameof(HasProject));
        // HasProject es una propiedad calculada (no [ObservableProperty]), así que los
        // comandos que dependen de ella vía CanExecute=nameof(HasProject) no se enteran
        // solos de que CurrentProject cambió: hay que pedirles explícitamente que
        // reevalúen si pueden ejecutarse. Sin esto, Guardar/Compartir/Exportar PDF
        // quedan deshabilitados para siempre desde el arranque.
        SaveProjectCommand.NotifyCanExecuteChanged();
        ExportPdfCommand.NotifyCanExecuteChanged();
    }

    // ---------- Acciones de archivo (Nuevo / Abrir / Guardar / Exportar) ----------

    [RelayCommand]
    private async Task NewProject()
    {
        CurrentProject = null;
        CurrentSolution = null;
        StatusMessage = "Elegí una plantilla para empezar.";
        await _navigation.GoToAsync(Routes.NewProjectGalleryPage);
    }

    [RelayCommand]
    private async Task OpenProject()
    {
        try
        {
            var project = await _projectFileService.OpenAsync();
            if (project is null) return; // cancelado por el usuario

            CurrentProject = project;
            CurrentSolution = null;

            // Si el proyecto ya se había resuelto la última vez que se guardó, se vuelve a
            // resolver automáticamente con el mismo método (el algoritmo es determinístico:
            // mismos datos + mismo método = misma solución) y se muestra directo el resultado,
            // en vez de obligar a repetir Validar/Agregar ficticio/Resolver a mano.
            var method = project.WasSolved && project.MethodUsed is not null
                ? Methods.FirstOrDefault(m => m.Name == project.MethodUsed)
                : null;

            if (method is not null)
            {
                var solution = method.Solve(project.ToProblem());
                CurrentSolution = solution;
                SolutionWasPreloaded = true;
                StatusMessage = $"Proyecto \"{project.Name}\" abierto y resuelto con {method.Name}.";

                // Se pasa primero por la hoja de cálculo (para que quede en la pila de
                // navegación con los datos ya cargados) y recién ahí a la solución, así
                // "Volver a editar" desde la solución funciona como cualquier otro camino.
                await _navigation.GoToAsync(Routes.NewProblemPage);
                await _navigation.GoToAsync(Routes.SolutionPage);
                return;
            }

            StatusMessage = $"Proyecto \"{project.Name}\" abierto correctamente.";
            await _navigation.GoToAsync(Routes.NewProblemPage);
        }
        catch (Exception ex)
        {
            StatusMessage = $"No se pudo abrir el proyecto: {ex.Message}";
            await _dialogs.AlertAsync("No se pudo abrir el proyecto", ex.Message);
        }
    }

    [RelayCommand(CanExecute = nameof(HasProject))]
    private async Task SaveProject()
    {
        if (CurrentProject is null) return;
        try
        {
            var path = await _projectFileService.SaveAsAsync(CurrentProject);

            if (path is null)
            {
                // El usuario cerró/canceló el diálogo "Guardar como" sin elegir ubicación.
                StatusMessage = "Guardado cancelado.";
                return;
            }

            StatusMessage = $"Proyecto guardado en: {path}";
            // Confirmación visible sin importar desde qué pantalla se haya disparado el
            // guardado (StatusMessage solo se ve en la barra de estado de Inicio).
            await _dialogs.AlertAsync("Proyecto guardado", $"Se guardó en:\n{path}");
        }
        catch (Exception ex)
        {
            StatusMessage = $"No se pudo guardar el proyecto: {ex.Message}";
            await _dialogs.AlertAsync("No se pudo guardar el proyecto", ex.Message);
        }
    }

    [RelayCommand(CanExecute = nameof(HasProject))]
    private Task ExportPdf() => ExportPdfAsync();

    /// <summary>
    /// Genera el informe PDF del proyecto actual y abre el diálogo de compartir. Lo usan
    /// tanto el botón de Inicio como el de la pantalla de resultados; esta última pasa las
    /// etiquetas de fila/columna tal como están en pantalla (por si el usuario las renombró).
    /// </summary>
    public async Task ExportPdfAsync(string[]? rowLabels = null, string[]? colLabels = null)
    {
        if (CurrentProject is null) return;
        try
        {
            var fileName = ReportFileName.For(CurrentProject.Name);
            var path = _pdfExportService.Export(CurrentProject, CurrentSolution, fileName, rowLabels, colLabels);
            StatusMessage = $"Informe PDF generado: {path}";
            await _projectFileService.ShareAsync(path, "Exportar informe PDF");
        }
        catch (Exception ex)
        {
            StatusMessage = $"No se pudo exportar el PDF: {ex.Message}";
            await _dialogs.AlertAsync("No se pudo exportar el PDF", ex.Message);
        }
    }

    /// <summary>Tiles de la galería "Nuevo": "Problema en blanco" primero, después uno por método.</summary>
    public IEnumerable<GalleryTile> ProblemTemplates =>
        new[]
        {
            new GalleryTile { Name = "Problema en blanco", Description = "Elegí el método más tarde.", Icon = "📄", Method = null }
        }
        .Concat(Methods.Select(m => new GalleryTile
        {
            Name = m.Name,
            Description = m.Description,
            Icon = m.Icon,
            Method = m
        }));

    [RelayCommand]
    private async Task GoHomeFromGallery() => await _navigation.GoToAsync(Routes.Back);

    // ---------- Selección de plantilla desde la galería "Nuevo" ----------

    [RelayCommand]
    private async Task SelectTemplate(GalleryTile tile)
    {
        if (tile.Method is null)
        {
            await _navigation.GoToAsync(Routes.NewProblemPage);
            return;
        }

        await _navigation.GoToAsync(Routes.NewProblemPage, new Dictionary<string, object>
        {
            { "method", tile.Method }
        });
    }

    // ---------- Ayuda ----------

    [RelayCommand]
    private async Task ShowHelp() => await _navigation.GoToAsync(Routes.HelpPage);
}
