using TransporteMAUI.Algorithms;

namespace TransporteMAUI.ViewModels;

/// <summary>
/// Representa un tile de la galería "Nuevo" (equivalente a una plantilla de Word):
/// puede ser el tile "Problema en blanco" (Method = null) o uno de los tres métodos.
/// </summary>
public class GalleryTile
{
    public string Name { get; init; } = string.Empty;
    public string Description { get; init; } = string.Empty;
    public string Icon { get; init; } = "📄";

    /// <summary>Null para el tile "Problema en blanco"; el método a preseleccionar en los demás.</summary>
    public ITransportationMethod? Method { get; init; }
}
