using CommunityToolkit.Mvvm.ComponentModel;

namespace TransporteMAUI.ViewModels;

/// <summary>
/// Representa un valor numérico editable en la grilla (una celda de costo, una oferta
/// o una demanda). Se maneja como texto para permitir que el campo esté vacío mientras
/// el usuario escribe, y se valida recién al presionar "Validar totales".
/// </summary>
public partial class EditableValue : ObservableObject
{
    [ObservableProperty]
    private string text = string.Empty;

    /// <summary>Fila (origen) a la que pertenece. -1 si es un valor de demanda (no tiene fila).</summary>
    public int Row { get; init; } = -1;

    /// <summary>Columna (destino) a la que pertenece. -1 si es un valor de oferta (no tiene columna).</summary>
    public int Col { get; init; } = -1;

    /// <summary>
    /// Etiqueta para mostrar cuando esta celda se lista sola (oferta o demanda):
    /// "O{fila+1}" si es una oferta (tiene fila y no columna), "D{col+1}" si es una
    /// demanda (tiene columna y no fila). Vacío para celdas de costo (tienen ambas).
    /// </summary>
    public string Label =>
        (Row >= 0, Col >= 0) switch
        {
            (true, false) => $"O{Row + 1}",
            (false, true) => $"D{Col + 1}",
            _ => string.Empty
        };

    /// <summary>True si el texto actual es numérico y no negativo. Acepta '.' o ',' como separador decimal.</summary>
    public bool TryGetValue(out double value)
    {
        var normalized = Text.Trim().Replace(',', '.');
        return double.TryParse(normalized, System.Globalization.NumberStyles.Number,
            System.Globalization.CultureInfo.InvariantCulture, out value) && value >= 0;
    }
}
