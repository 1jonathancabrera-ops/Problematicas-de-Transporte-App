using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Maui.Graphics;
using TransporteMAUI.Models;
using TransporteMAUI.Navigation;
using TransporteMAUI.Services;

namespace TransporteMAUI.ViewModels;

/// <summary>Una columna de la tabla resuelta (encabezado de destino). El label es editable:
/// el usuario puede tocarlo y escribir un nombre propio (ej. "Sucursal Norte") en vez de "D1".</summary>
public partial class SolutionColumnHeader : ObservableObject
{
    [ObservableProperty]
    private string label = string.Empty;

    public bool IsFictitious { get; init; }
}

/// <summary>Una fila de la tabla resuelta, ya lista para bindear en la UI. El label es
/// editable: el usuario puede tocarlo y escribir un nombre propio en vez de "O1".</summary>
public partial class SolutionRow : ObservableObject
{
    [ObservableProperty]
    private string label = string.Empty;

    public bool IsFictitiousRow { get; init; }
    public List<SolutionCellDisplay> Cells { get; init; } = new();
    public double Total { get; init; }

    /// <summary>Penalización de esta fila en cada iteración de Vogel (vacía para los otros métodos).</summary>
    public List<PenaltyCellDisplay> Penalties { get; init; } = new();
}

public class SolutionCellDisplay
{
    public string Text { get; init; } = string.Empty;
    public bool IsUsed { get; init; }
    public bool IsFictitious { get; init; }

    /// <summary>Color de fondo ya resuelto para pintar la celda (dorado=usada, gris oscuro=ficticia, superficie normal=sin uso).</summary>
    public Color BackgroundColor => (IsUsed, IsFictitious) switch
    {
        (true, true) => Color.FromArgb("#5A4A22"),
        (true, false) => Color.FromArgb("#4A3A18"),
        (false, true) => Color.FromArgb("#2A241A"),
        _ => Color.FromArgb("#1E1811")
    };

    public Color BorderColor => IsUsed ? Color.FromArgb("#F0C468") : Color.FromArgb("#3A311F");
}

/// <summary>
/// Una celda de la tabla de penalizaciones de Vogel: el valor de la penalización en esa
/// iteración (vacío si la fila/columna ya estaba eliminada), y si corresponde tacharla
/// porque fue la última iteración en la que esa fila/columna estuvo activa. El "cómo"
/// tacharla visualmente (TextDecorations, específico de MAUI Controls) queda del lado de
/// la vista; acá solo vive el dato "IsFinal".
/// </summary>
public class PenaltyCellDisplay
{
    public string Text { get; init; } = string.Empty;
    public bool IsFinal { get; init; }
}

/// <summary>Una fila "Penalización N" al pie de la tabla, con un valor por columna.</summary>
public class PenaltyRow
{
    public string Label { get; init; } = string.Empty;
    public List<PenaltyCellDisplay> Cells { get; init; } = new();
}

/// <summary>Una fila de la tabla comparativa de métodos: solo el costo final de cada uno, sin la asignación completa.</summary>
public class MethodComparisonRow
{
    public string Name { get; init; } = string.Empty;
    public string CostText { get; init; } = string.Empty;
    public bool IsBest { get; init; }
}

/// <summary>
/// ViewModel de la pantalla de resultados: arma la grilla de solo-lectura a partir de
/// <see cref="TransportationSolution"/> y controla la revelación progresiva del cálculo
/// de costo total (equivalente al botón "Calcular costo total" de la versión web).
/// </summary>
public partial class SolutionViewModel : ObservableObject
{
    private readonly MainViewModel _main;
    private readonly INavigationService _navigation;

    public TransportationProject? Project => _main.CurrentProject;
    public TransportationSolution? Solution => _main.CurrentSolution;

    public ObservableCollection<SolutionColumnHeader> Columns { get; } = new();
    public ObservableCollection<SolutionRow> Rows { get; } = new();
    public ObservableCollection<string> DemandTotals { get; } = new();

    /// <summary>Encabezados "Penalización 1", "Penalización 2"... (una por iteración de Vogel).</summary>
    public ObservableCollection<string> PenaltyHeaders { get; } = new();

    /// <summary>Filas "Penalización N" al pie de la tabla, con la penalización de cada columna en esa iteración.</summary>
    public ObservableCollection<PenaltyRow> ColumnPenaltyRows { get; } = new();

    /// <summary>Costo final de cada método sobre este mismo problema, para la comparación al lado del costo total.</summary>
    public ObservableCollection<MethodComparisonRow> MethodComparison { get; } = new();

    public bool HasMethodComparison => MethodComparison.Count > 0;

    [ObservableProperty]
    private bool isVogel;

    [ObservableProperty]
    private string totalSupplyText = string.Empty;

    [ObservableProperty]
    private string totalDemandText = string.Empty;

    [ObservableProperty]
    private string headerSummary = string.Empty;

    [ObservableProperty]
    private string balanceSummary = string.Empty;

    [ObservableProperty]
    private bool showCostBreakdown;

    [ObservableProperty]
    private string costExpression = string.Empty;

    [ObservableProperty]
    private string totalCostText = string.Empty;

    public SolutionViewModel(MainViewModel main, INavigationService navigation)
    {
        _main = main;
        _navigation = navigation;
        BuildDisplay();
    }

    private void BuildDisplay()
    {
        Columns.Clear();
        Rows.Clear();
        DemandTotals.Clear();
        PenaltyHeaders.Clear();
        ColumnPenaltyRows.Clear();
        ShowCostBreakdown = _main.SolutionWasPreloaded;

        var solution = Solution;
        var project = Project;
        if (solution is null || project is null) return;

        HeaderSummary = $"Método utilizado: {solution.MethodName}    ·    " +
                        $"Orígenes: {project.OriginCount}    ·    Destinos: {project.DestinationCount}";

        BalanceSummary = solution.WasBalancedOriginally
            ? "Problema balanceado"
            : solution.FictitiousType == FictitiousType.Origin
                ? $"Problema no balanceado: se agregó un origen ficticio de {solution.FictitiousAmount:0.##} unidades."
                : $"Problema no balanceado: se agregó un destino ficticio de {solution.FictitiousAmount:0.##} unidades.";

        var iterations = solution.VogelIterations;
        IsVogel = iterations is { Count: > 0 };

        if (IsVogel)
            for (int k = 0; k < iterations!.Count; k++)
                PenaltyHeaders.Add($"Penalización {k + 1}");

        for (int j = 0; j < solution.Cols; j++)
        {
            var esFicticia = solution.Cells.Any(c => c.Col == j && c.IsFictitiousCol);
            Columns.Add(new SolutionColumnHeader { Label = esFicticia ? "Demanda ficticia" : $"D{j + 1}", IsFictitious = esFicticia });
        }

        for (int i = 0; i < solution.Rows; i++)
        {
            var filaFicticia = solution.Cells.Any(c => c.Row == i && c.IsFictitiousRow);
            var row = new SolutionRow
            {
                Label = filaFicticia ? "Oferta ficticia" : $"O{i + 1}",
                IsFictitiousRow = filaFicticia,
                Total = solution.SupplyRowTotal(i)
            };

            for (int j = 0; j < solution.Cols; j++)
            {
                var cell = solution.GetCell(i, j);
                row.Cells.Add(new SolutionCellDisplay
                {
                    Text = cell.Display,
                    IsUsed = cell.IsUsed,
                    IsFictitious = cell.IsFictitious
                });
            }

            if (IsVogel)
            {
                for (int k = 0; k < iterations!.Count; k++)
                {
                    var penal = iterations[k].RowPenalties[i];
                    row.Penalties.Add(new PenaltyCellDisplay
                    {
                        Text = penal is double p ? p.ToString("0.##") : string.Empty,
                        IsFinal = iterations[k].EliminatedRow == i
                    });
                }
            }

            Rows.Add(row);
        }

        for (int j = 0; j < solution.Cols; j++)
            DemandTotals.Add(solution.DemandColTotal(j).ToString("0.##"));

        if (IsVogel)
        {
            for (int k = 0; k < iterations!.Count; k++)
            {
                var penaltyRow = new PenaltyRow { Label = $"Penalización {k + 1}" };
                for (int j = 0; j < solution.Cols; j++)
                {
                    var penal = iterations[k].ColPenalties[j];
                    penaltyRow.Cells.Add(new PenaltyCellDisplay
                    {
                        Text = penal is double p ? p.ToString("0.##") : string.Empty,
                        IsFinal = iterations[k].EliminatedCol == j
                    });
                }
                ColumnPenaltyRows.Add(penaltyRow);
            }

            TotalSupplyText = project.Supply.Sum().ToString("0.##");
            TotalDemandText = project.Demand.Sum().ToString("0.##");
        }

        CostExpression = string.Join("  +  ", solution.CostExpressionTerms);
        TotalCostText = $"Costo total = {solution.TotalCost:0.##}";

        // Comparación de métodos: se corre cada método sobre el mismo problema (son
        // rápidos para las matrices chicas de un TP) y se muestra solo el costo final de
        // cada uno, no la tabla de asignación completa — no tiene sentido mostrar 3 tablas
        // grandes solo para comparar un número.
        MethodComparison.Clear();
        var problem = project.ToProblem();
        var resultados = _main.Methods
            .Select(m => (m.Name, Cost: m.Solve(problem).TotalCost))
            .ToList();
        var mejorCosto = resultados.Min(r => r.Cost);
        foreach (var r in resultados)
        {
            MethodComparison.Add(new MethodComparisonRow
            {
                Name = r.Name,
                CostText = r.Cost.ToString("0.##"),
                IsBest = r.Cost <= mejorCosto + 0.0000001
            });
        }
    }

    [RelayCommand]
    private void CalculateCost() => ShowCostBreakdown = true;

    [RelayCommand]
    private async Task BackToEdit() => await _navigation.GoToAsync(Routes.Back);

    [RelayCommand]
    private async Task GoHome() => await _navigation.GoToAsync($"//{Routes.MainPage}");

    [RelayCommand]
    private Task SaveProject() => _main.SaveProjectCommand.ExecuteAsync(null);

    /// <summary>
    /// Exporta usando las etiquetas de fila/columna TAL COMO están en pantalla en este
    /// momento — incluyendo cualquier renombre que el usuario haya hecho tocando "O1"/"D1".
    /// </summary>
    [RelayCommand]
    private Task ExportPdf() => _main.ExportPdfAsync(
        Rows.Select(r => r.Label).ToArray(),
        Columns.Select(c => c.Label).ToArray());
}
