using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using TransporteMAUI.Algorithms;
using TransporteMAUI.Models;
using TransporteMAUI.Navigation;
using TransporteMAUI.Services;

namespace TransporteMAUI.ViewModels;

/// <summary>
/// ViewModel de la pantalla "Nuevo problema / hoja de cálculo": permite definir las
/// dimensiones, cargar costos, ofertas y demandas, validar el balance del problema,
/// agregar el elemento ficticio si hace falta, elegir método y resolver.
/// Equivale a la lógica de generarInputs()/calcular()/agregarFicticio()/resolver() del
/// proyecto web original, pero reutilizando la misma pantalla para los tres métodos.
/// </summary>
public partial class NewProblemViewModel : ObservableObject, IQueryParameterReceiver
{
    private readonly MainViewModel _main;
    private readonly INavigationService _navigation;
    private readonly IDialogService _dialogs;

    public IEnumerable<ITransportationMethod> Methods => _main.Methods;

    [ObservableProperty]
    private string projectName = "Nuevo proyecto";

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(GenerateTableCommand))]
    private int originCount = 3;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(GenerateTableCommand))]
    private int destinationCount = 3;

    [ObservableProperty]
    private bool tableGenerated;

    public ObservableCollection<EditableValue> CostCells { get; } = new();
    public ObservableCollection<EditableValue> SupplyCells { get; } = new();
    public ObservableCollection<EditableValue> DemandCells { get; } = new();

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(SolveCommand))]
    private ITransportationMethod? selectedMethod;

    [ObservableProperty]
    private string totalsMessage = string.Empty;

    [ObservableProperty]
    private string balanceMessage = string.Empty;

    [ObservableProperty]
    private bool isBalanced;

    [ObservableProperty]
    private bool needsFictitiousChoice;

    [ObservableProperty]
    private string fictitiousQuestion = string.Empty;

    [ObservableProperty]
    private string fictitiousButtonLabel = string.Empty;

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(SolveCommand))]
    private bool readyToSolve;

    private FictitiousType _pendingType = FictitiousType.None;
    private double _pendingAmount;

    public NewProblemViewModel(MainViewModel main, INavigationService navigation, IDialogService dialogs)
    {
        _main = main;
        _navigation = navigation;
        _dialogs = dialogs;
        SelectedMethod = Methods.FirstOrDefault();

        // Si se llega desde "Abrir proyecto", precargar sus datos.
        if (_main.CurrentProject is { } project)
        {
            ProjectName = project.Name;
            OriginCount = project.OriginCount;
            DestinationCount = project.DestinationCount;
            GenerateTable();
            LoadValuesFromProject(project);
        }
    }

    public void ApplyQueryAttributes(IDictionary<string, object> query)
    {
        if (query.TryGetValue("method", out var m) && m is ITransportationMethod method)
        {
            SelectedMethod = Methods.FirstOrDefault(x => x.Name == method.Name) ?? SelectedMethod;
        }
    }

    private void LoadValuesFromProject(TransportationProject project)
    {
        for (int i = 0; i < project.OriginCount; i++)
        {
            SupplyCells[i].Text = project.Supply[i].ToString("0.##");
            for (int j = 0; j < project.DestinationCount; j++)
                CostCells[i * DestinationCount + j].Text = project.Costs[i][j].ToString("0.##");
        }
        for (int j = 0; j < project.DestinationCount; j++)
            DemandCells[j].Text = project.Demand[j].ToString("0.##");
    }

    private bool CanGenerateTable() => OriginCount > 0 && DestinationCount > 0;

    [RelayCommand(CanExecute = nameof(CanGenerateTable))]
    private void GenerateTable()
    {
        CostCells.Clear();
        SupplyCells.Clear();
        DemandCells.Clear();

        for (int i = 0; i < OriginCount; i++)
        {
            for (int j = 0; j < DestinationCount; j++)
                CostCells.Add(new EditableValue { Row = i, Col = j });
            SupplyCells.Add(new EditableValue { Row = i });
        }
        for (int j = 0; j < DestinationCount; j++)
            DemandCells.Add(new EditableValue { Col = j });

        TableGenerated = true;
        ResetValidationState();

        WeakReferenceMessenger.Default.Send(new TableGeneratedMessage((OriginCount, DestinationCount)));
    }

    private void ResetValidationState()
    {
        TotalsMessage = string.Empty;
        BalanceMessage = string.Empty;
        IsBalanced = false;
        NeedsFictitiousChoice = false;
        ReadyToSolve = false;
        _pendingType = FictitiousType.None;
        _pendingAmount = 0;
    }

    [RelayCommand]
    private async Task ValidateTotals()
    {
        if (!TableGenerated) return;

        if (!TryBuildProblem(out var problem, out var error))
        {
            await _dialogs.AlertAsync("Datos incompletos", error!);
            return;
        }

        TotalsMessage = $"Oferta total: {problem!.TotalSupply:0.##}    Demanda total: {problem.TotalDemand:0.##}";
        NeedsFictitiousChoice = false;

        if (problem.IsBalanced)
        {
            BalanceMessage = "✅ Problema balanceado.";
            IsBalanced = true;
            ReadyToSolve = true;
            _pendingType = FictitiousType.None;
            return;
        }

        IsBalanced = false;
        var diff = problem.Difference;
        var tipo = problem.RequiredFictitious;
        _pendingType = tipo;
        _pendingAmount = diff;

        if (tipo == FictitiousType.Destination)
        {
            BalanceMessage = $"⚠ Problema no balanceado. La oferta supera a la demanda en {diff:0.##} unidades.";
            FictitiousQuestion = "Se agregará un destino ficticio (demanda) con costo 0 para poder resolver.";
            FictitiousButtonLabel = "Agregar destino ficticio";
        }
        else
        {
            BalanceMessage = $"⚠ Problema no balanceado. La demanda supera a la oferta en {diff:0.##} unidades.";
            FictitiousQuestion = "Se agregará un origen ficticio (oferta) con costo 0 para poder resolver.";
            FictitiousButtonLabel = "Agregar origen ficticio";
        }

        NeedsFictitiousChoice = true;
        ReadyToSolve = false;
    }

    [RelayCommand]
    private void AddFictitious()
    {
        if (_pendingType == FictitiousType.None) return;

        var etiqueta = _pendingType == FictitiousType.Origin ? "origen" : "destino";
        BalanceMessage = $"✅ Problema balanceado correctamente.\nSe agregó un {etiqueta} ficticio de {_pendingAmount:0.##} unidades.";
        NeedsFictitiousChoice = false;
        ReadyToSolve = true;
    }

    private bool CanSolve() => ReadyToSolve && SelectedMethod is not null;

    [RelayCommand(CanExecute = nameof(CanSolve))]
    private async Task Solve()
    {
        if (SelectedMethod is null) return;

        if (!TryBuildProblem(out var problem, out var error))
        {
            await _dialogs.AlertAsync("Datos incompletos", error!);
            return;
        }

        // GetBalanced() dentro del algoritmo vuelve a calcular el ficticio automáticamente
        // a partir de los mismos datos, así que no hace falta mutar la matriz acá: la
        // confirmación del usuario en "Agregar Ficticio" es solo informativa/UX.
        var solution = SelectedMethod.Solve(problem!);

        var project = TransportationProject.FromProblem(problem!, ProjectName);
        project.MethodUsed = solution.MethodName;
        project.WasSolved = true;

        _main.CurrentProject = project;
        _main.CurrentSolution = solution;
        _main.SolutionWasPreloaded = false;
        _main.StatusMessage = $"Problema resuelto con el método {solution.MethodName}.";

        await _navigation.GoToAsync(Routes.SolutionPage);
    }

    [RelayCommand]
    private async Task Reset()
    {
        bool confirmar = await _dialogs.ConfirmAsync(
            "¿Reiniciar el problema?", "Se perderán todos los datos ingresados. No se puede deshacer.", "Reiniciar", "Cancelar");
        if (!confirmar) return;

        OriginCount = 3;
        DestinationCount = 3;
        ProjectName = "Nuevo proyecto";
        TableGenerated = false;
        CostCells.Clear();
        SupplyCells.Clear();
        DemandCells.Clear();
        ResetValidationState();
        WeakReferenceMessenger.Default.Send(new TableGeneratedMessage((0, 0)));
    }

    [RelayCommand]
    private async Task GoHome() => await _navigation.GoToAsync(Routes.Back);

    /// <summary>
    /// Vuelca las celdas de la grilla a un <see cref="TransportationProblem"/>, validando
    /// que todo esté completo y que no haya valores negativos (equivalente a las
    /// validaciones de calcular()/resolver() en la versión web).
    /// </summary>
    private bool TryBuildProblem(out TransportationProblem? problem, out string? error)
    {
        problem = null;

        var supply = new double[OriginCount];
        for (int i = 0; i < OriginCount; i++)
        {
            if (!SupplyCells[i].TryGetValue(out var v))
            {
                error = $"Revisá la oferta O{i + 1}: ingresá un número mayor o igual a 0.";
                return false;
            }
            supply[i] = v;
        }

        var demand = new double[DestinationCount];
        for (int j = 0; j < DestinationCount; j++)
        {
            if (!DemandCells[j].TryGetValue(out var v))
            {
                error = $"Revisá la demanda D{j + 1}: ingresá un número mayor o igual a 0.";
                return false;
            }
            demand[j] = v;
        }

        var costs = new double[OriginCount][];
        for (int i = 0; i < OriginCount; i++)
        {
            costs[i] = new double[DestinationCount];
            for (int j = 0; j < DestinationCount; j++)
            {
                var cell = CostCells[i * DestinationCount + j];
                if (!cell.TryGetValue(out var v))
                {
                    error = $"Revisá el costo O{i + 1}-D{j + 1}: ingresá un número mayor o igual a 0.";
                    return false;
                }
                costs[i][j] = v;
            }
        }

        error = null;
        problem = new TransportationProblem(costs, supply, demand);
        return true;
    }
}
