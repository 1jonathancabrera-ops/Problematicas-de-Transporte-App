using CommunityToolkit.Mvvm.Messaging.Messages;

namespace TransporteMAUI.ViewModels;

/// <summary>
/// Se envía desde <see cref="NewProblemViewModel"/> cuando cambian las dimensiones del
/// problema (orígenes/destinos), para que la vista reconstruya la grilla de Entry
/// controles dinámicamente (equivalente a "generarInputs()" en la versión web).
/// </summary>
public class TableGeneratedMessage : ValueChangedMessage<(int origins, int destinations)>
{
    public TableGeneratedMessage((int origins, int destinations) value) : base(value) { }
}
