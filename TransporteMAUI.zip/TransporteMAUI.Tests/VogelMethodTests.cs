using TransporteMAUI.Algorithms;
using TransporteMAUI.Models;
using Xunit;

namespace TransporteMAUI.Tests;

public class VogelMethodTests
{
    private readonly VogelMethod _method = new();
    private readonly NorthwestCornerMethod _northwest = new();

    [Fact]
    public void ProblemaBalanceado_ProduceSolucionFactible()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 4, 6, 8 }, new double[] { 5, 3, 7 }, new double[] { 9, 4, 2 } },
            supply: new double[] { 50, 40, 60 },
            demand: new double[] { 30, 70, 50 });

        var solution = _method.Solve(problem);

        SolutionAssertions.AssertFeasible(solution, problem.GetBalanced());
    }

    [Fact]
    public void GeneralmenteMejoraOIgualaElCostoDeEsquinaNoroeste()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 4, 6, 8 }, new double[] { 5, 3, 7 }, new double[] { 9, 4, 2 } },
            supply: new double[] { 50, 40, 60 },
            demand: new double[] { 30, 70, 50 });

        var vogel = _method.Solve(problem);
        var northwest = _northwest.Solve(problem);

        Assert.True(vogel.TotalCost <= northwest.TotalCost,
            $"Vogel ({vogel.TotalCost}) debería costar igual o menos que Esquina Noroeste ({northwest.TotalCost}).");
    }

    [Fact]
    public void EmpateDePenalizaciones_NoRompeElAlgoritmoYProduceSolucionFactible()
    {
        // Matriz simétrica: todas las filas y columnas tienen la misma penalización inicial.
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 2, 4 }, new double[] { 4, 2 } },
            supply: new double[] { 10, 10 },
            demand: new double[] { 10, 10 });

        var solution = _method.Solve(problem);

        SolutionAssertions.AssertFeasible(solution, problem.GetBalanced());
    }

    [Fact]
    public void DemandaMayorQueOferta_ManejaCorrectamenteElOrigenFicticio()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 4, 6, 8 } },
            supply: new double[] { 50 },
            demand: new double[] { 30, 30, 30 });

        var solution = _method.Solve(problem);

        Assert.Equal(FictitiousType.Origin, solution.FictitiousType);
        SolutionAssertions.AssertFeasible(solution, problem.GetBalanced());
    }

    [Fact]
    public void MatrizMasGrande_4x5_ProduceSolucionFactible()
    {
        var costs = new[]
        {
            new double[] { 4, 8, 8, 3, 6 },
            new double[] { 6, 5, 3, 9, 2 },
            new double[] { 7, 4, 6, 2, 5 },
            new double[] { 3, 9, 1, 7, 4 }
        };
        var supply = new double[] { 40, 60, 50, 30 };
        var demand = new double[] { 30, 40, 50, 30, 30 };

        var problem = new TransportationProblem(costs, supply, demand);
        var solution = _method.Solve(problem);

        SolutionAssertions.AssertFeasible(solution, problem.GetBalanced());
    }

    [Fact]
    public void UnaSolaFilaActiva_AsignaElRestanteSinCalcularPenalizaciones()
    {
        // Fuerza rápidamente a que quede una sola fila activa.
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 1, 2, 3 }, new double[] { 4, 5, 6 } },
            supply: new double[] { 5, 25 },
            demand: new double[] { 10, 10, 10 });

        var solution = _method.Solve(problem);

        SolutionAssertions.AssertFeasible(solution, problem.GetBalanced());
    }

    [Fact]
    public void RegistraUnaIteracionDePenalizacionPorRonda()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 4, 6, 8 }, new double[] { 5, 3, 7 }, new double[] { 9, 4, 2 } },
            supply: new double[] { 50, 40, 60 },
            demand: new double[] { 30, 70, 50 });

        var solution = _method.Solve(problem);
        var bp = problem.GetBalanced();

        Assert.NotNull(solution.VogelIterations);
        Assert.NotEmpty(solution.VogelIterations!);

        foreach (var iteration in solution.VogelIterations!)
        {
            // Los arrays de penalización siempre miden lo mismo que filas/columnas del problema.
            Assert.Equal(bp.Rows, iteration.RowPenalties.Length);
            Assert.Equal(bp.Cols, iteration.ColPenalties.Length);

            // En cada iteración se elimina como máximo una fila o una columna (nunca ambas).
            Assert.False(iteration.EliminatedRow.HasValue && iteration.EliminatedCol.HasValue);
        }

        // Cada fila y cada columna deben quedar eliminadas en exactamente una iteración
        // (o ninguna, si sobrevivió hasta el paso final de asignación directa).
        var filasEliminadas = solution.VogelIterations!.Where(it => it.EliminatedRow.HasValue).Select(it => it.EliminatedRow!.Value);
        Assert.Equal(filasEliminadas.Distinct().Count(), filasEliminadas.Count());
    }

    [Fact]
    public void MetodosSinVogel_NoRegistranIteraciones()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 4, 6 }, new double[] { 5, 3 } },
            supply: new double[] { 10, 10 },
            demand: new double[] { 10, 10 });

        var solution = _northwest.Solve(problem);

        Assert.Null(solution.VogelIterations);
    }
}
