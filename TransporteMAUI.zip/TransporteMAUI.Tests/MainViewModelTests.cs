using TransporteMAUI.Algorithms;
using TransporteMAUI.Models;
using TransporteMAUI.Navigation;
using TransporteMAUI.Tests.Fakes;
using TransporteMAUI.ViewModels;
using Xunit;

namespace TransporteMAUI.Tests;

public class MainViewModelTests
{
    private static readonly ITransportationMethod[] Methods =
        { new NorthwestCornerMethod(), new LeastCostMethod(), new VogelMethod() };

    private static (MainViewModel vm, FakeNavigationService nav, FakeDialogService dialogs,
        FakeProjectFileService files, FakePdfExportService pdf) Build()
    {
        var nav = new FakeNavigationService();
        var dialogs = new FakeDialogService();
        var files = new FakeProjectFileService();
        var pdf = new FakePdfExportService();
        var vm = new MainViewModel(Methods, files, pdf, nav, dialogs);
        return (vm, nav, dialogs, files, pdf);
    }

    private static TransportationProject SolvedProject(string methodName)
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 1, 2 }, new double[] { 3, 4 } },
            supply: new double[] { 5, 5 },
            demand: new double[] { 5, 5 });

        var project = TransportationProject.FromProblem(problem, "Proyecto de prueba");
        project.WasSolved = true;
        project.MethodUsed = methodName;
        return project;
    }

    [Fact]
    public void AlArranque_ComandosQueRequierenProyecto_EstanDeshabilitados()
    {
        var (vm, _, _, _, _) = Build();

        // Regresión del bug real: estos comandos dependían de HasProject (una propiedad
        // calculada) sin que nada les avisara cuando CurrentProject cambiaba, así que
        // quedaban deshabilitados para siempre desde el arranque.
        Assert.False(vm.SaveProjectCommand.CanExecute(null));
        Assert.False(vm.ExportPdfCommand.CanExecute(null));
    }

    [Fact]
    public void AlSetearCurrentProject_LosComandosDeGuardadoSeHabilitan()
    {
        var (vm, _, _, _, _) = Build();

        vm.CurrentProject = SolvedProject("Vogel");

        Assert.True(vm.SaveProjectCommand.CanExecute(null));
        Assert.True(vm.ExportPdfCommand.CanExecute(null));
    }

    [Fact]
    public async Task AbrirProyecto_CanceladoPorElUsuario_NoCambiaEstadoNiNavega()
    {
        var (vm, nav, _, files, _) = Build();
        files.NextOpenedProject = null; // simula que el usuario cerró el selector de archivos

        await vm.OpenProjectCommand.ExecuteAsync(null);

        Assert.Null(vm.CurrentProject);
        Assert.Empty(nav.Calls);
    }

    [Fact]
    public async Task AbrirProyecto_YaResuelto_LoResuelveDeNuevoYVaDirectoALaSolucion()
    {
        var (vm, nav, _, files, _) = Build();
        files.NextOpenedProject = SolvedProject("Menor Costo");

        await vm.OpenProjectCommand.ExecuteAsync(null);

        Assert.NotNull(vm.CurrentSolution);
        Assert.Equal("Menor Costo", vm.CurrentSolution!.MethodName);
        // El costo total debe mostrarse ya revelado en la pantalla de resultados, no
        // detrás del botón "Mostrar costo total" (el proyecto ya venía resuelto).
        Assert.True(vm.SolutionWasPreloaded);
        // Pasa por NewProblemPage primero (para que "Volver a editar" tenga a dónde volver)
        // y termina en SolutionPage.
        Assert.Equal(new[] { Routes.NewProblemPage, Routes.SolutionPage }, nav.Calls.Select(c => c.Route));
    }

    [Fact]
    public async Task AbrirProyecto_NoResueltoTodavia_VaALaHojaDeCalculoSinResolver()
    {
        var (vm, nav, _, files, _) = Build();
        var project = SolvedProject("Vogel");
        project.WasSolved = false;
        project.MethodUsed = null;
        files.NextOpenedProject = project;

        await vm.OpenProjectCommand.ExecuteAsync(null);

        Assert.Null(vm.CurrentSolution);
        Assert.Equal(new[] { Routes.NewProblemPage }, nav.Calls.Select(c => c.Route));
    }

    [Fact]
    public async Task SelectTemplate_ConMetodo_NavegaConElMetodoComoParametro()
    {
        var (vm, nav, _, _, _) = Build();
        var tile = new GalleryTile { Name = "Vogel", Method = Methods[2] };

        await vm.SelectTemplateCommand.ExecuteAsync(tile);

        Assert.Equal(Routes.NewProblemPage, nav.LastRoute);
        var (route, parameters) = nav.Calls[^1];
        Assert.NotNull(parameters);
        Assert.Same(Methods[2], parameters!["method"]);
    }

    [Fact]
    public async Task SelectTemplate_TileEnBlanco_NavegaSinParametros()
    {
        var (vm, nav, _, _, _) = Build();
        var tile = new GalleryTile { Name = "Problema en blanco", Method = null };

        await vm.SelectTemplateCommand.ExecuteAsync(tile);

        var (route, parameters) = nav.Calls[^1];
        Assert.Equal(Routes.NewProblemPage, route);
        Assert.Null(parameters);
    }
}
