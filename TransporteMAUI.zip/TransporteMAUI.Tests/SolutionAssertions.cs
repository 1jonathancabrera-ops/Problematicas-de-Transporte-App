using TransporteMAUI.Models;
using Xunit;

namespace TransporteMAUI.Tests;

internal static class SolutionAssertions
{
    /// <summary>
    /// Verifica que la solución sea factible: cada fila suma exactamente su oferta
    /// balanceada y cada columna suma exactamente su demanda balanceada, y que el
    /// costo total coincida con la suma manual de cantidad × costo.
    /// </summary>
    public static void AssertFeasible(TransportationSolution solution, BalancedProblem balanced)
    {
        for (int i = 0; i < balanced.Rows; i++)
            Assert.Equal(balanced.Supply[i], solution.SupplyRowTotal(i), precision: 6);

        for (int j = 0; j < balanced.Cols; j++)
            Assert.Equal(balanced.Demand[j], solution.DemandColTotal(j), precision: 6);

        double expectedTotal = solution.Cells.Where(c => c.Quantity > 0).Sum(c => c.Quantity * c.Cost);
        Assert.Equal(expectedTotal, solution.TotalCost, precision: 6);
    }
}
