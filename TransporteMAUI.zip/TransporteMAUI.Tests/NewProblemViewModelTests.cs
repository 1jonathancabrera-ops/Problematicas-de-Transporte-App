using TransporteMAUI.Algorithms;
using TransporteMAUI.Navigation;
using TransporteMAUI.Tests.Fakes;
using TransporteMAUI.ViewModels;
using Xunit;

namespace TransporteMAUI.Tests;

public class NewProblemViewModelTests
{
    private static readonly ITransportationMethod[] Methods =
        { new NorthwestCornerMethod(), new LeastCostMethod(), new VogelMethod() };

    private static (NewProblemViewModel vm, MainViewModel main, FakeNavigationService nav, FakeDialogService dialogs) Build()
    {
        var mainNav = new FakeNavigationService();
        var mainDialogs = new FakeDialogService();
        var main = new MainViewModel(Methods, new FakeProjectFileService(), new FakePdfExportService(),
            mainNav, mainDialogs);

        var nav = new FakeNavigationService();
        var dialogs = new FakeDialogService();
        var vm = new NewProblemViewModel(main, nav, dialogs);
        return (vm, main, nav, dialogs);
    }

    private static void FillMatrix(NewProblemViewModel vm, double[][] costs, double[] supply, double[] demand)
    {
        vm.GenerateTableCommand.Execute(null);
        for (int i = 0; i < supply.Length; i++)
        {
            vm.SupplyCells[i].Text = supply[i].ToString();
            for (int j = 0; j < demand.Length; j++)
                vm.CostCells[i * demand.Length + j].Text = costs[i][j].ToString();
        }
        for (int j = 0; j < demand.Length; j++)
            vm.DemandCells[j].Text = demand[j].ToString();
    }

    [Fact]
    public void GenerateTable_CreaLaCantidadDeCeldasSegunDimensiones()
    {
        var (vm, _, _, _) = Build();
        vm.OriginCount = 3;
        vm.DestinationCount = 4;

        vm.GenerateTableCommand.Execute(null);

        Assert.Equal(12, vm.CostCells.Count); // 3 x 4
        Assert.Equal(3, vm.SupplyCells.Count);
        Assert.Equal(4, vm.DemandCells.Count);
        Assert.True(vm.TableGenerated);
    }

    [Fact]
    public void SolveCommand_AlArranque_EstaDeshabilitado()
    {
        var (vm, _, _, _) = Build();

        // Regresión del bug real: ReadyToSolve/SelectedMethod cambiaban pero nada le
        // avisaba a SolveCommand que reevaluara su CanExecute, así que el botón "Resolver
        // con este método" quedaba deshabilitado para siempre aunque el problema
        // estuviera listo para resolver.
        Assert.False(vm.SolveCommand.CanExecute(null));
    }

    [Fact]
    public async Task ProblemaBalanceado_HabilitaElBotonDeResolver()
    {
        var (vm, _, _, _) = Build();
        FillMatrix(vm,
            costs: new[] { new double[] { 4, 6 }, new double[] { 5, 3 } },
            supply: new double[] { 10, 10 },
            demand: new double[] { 10, 10 });

        await vm.ValidateTotalsCommand.ExecuteAsync(null);

        Assert.True(vm.IsBalanced);
        Assert.True(vm.ReadyToSolve);
        Assert.True(vm.SolveCommand.CanExecute(null));
    }

    [Fact]
    public async Task ProblemaNoBalanceado_PideAgregarFicticioAntesDeHabilitarResolver()
    {
        var (vm, _, _, _) = Build();
        FillMatrix(vm,
            costs: new[] { new double[] { 4, 6 }, new double[] { 5, 3 } },
            supply: new double[] { 20, 10 },  // total 30
            demand: new double[] { 10, 10 }); // total 20 -> diferencia 10

        await vm.ValidateTotalsCommand.ExecuteAsync(null);

        Assert.False(vm.IsBalanced);
        Assert.True(vm.NeedsFictitiousChoice);
        Assert.False(vm.ReadyToSolve);
        Assert.False(vm.SolveCommand.CanExecute(null));

        vm.AddFictitiousCommand.Execute(null);

        Assert.False(vm.NeedsFictitiousChoice);
        Assert.True(vm.ReadyToSolve);
        Assert.True(vm.SolveCommand.CanExecute(null));
    }

    [Fact]
    public async Task Solve_ActualizaElProyectoCompartidoYNavegaALaSolucion()
    {
        var (vm, main, nav, _) = Build();
        FillMatrix(vm,
            costs: new[] { new double[] { 4, 6 }, new double[] { 5, 3 } },
            supply: new double[] { 10, 10 },
            demand: new double[] { 10, 10 });
        await vm.ValidateTotalsCommand.ExecuteAsync(null);

        await vm.SolveCommand.ExecuteAsync(null);

        Assert.NotNull(main.CurrentProject);
        Assert.NotNull(main.CurrentSolution);
        Assert.True(main.CurrentProject!.WasSolved);
        Assert.Equal(new[] { Routes.SolutionPage }, nav.Calls.Select(c => c.Route));
    }

    [Fact]
    public void ApplyQueryAttributes_PreseleccionaElMetodoRecibido()
    {
        var (vm, _, _, _) = Build();
        var vogel = Methods.Single(m => m.Name == "Vogel");

        vm.ApplyQueryAttributes(new Dictionary<string, object> { { "method", vogel } });

        Assert.Equal("Vogel", vm.SelectedMethod?.Name);
    }
}
