using TransporteMAUI.Models;
using Xunit;

namespace TransporteMAUI.Tests;

public class BalancingTests
{
    [Fact]
    public void ProblemaBalanceado_NoAgregaFicticio()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 1, 2 }, new double[] { 3, 4 } },
            supply: new double[] { 10, 20 },
            demand: new double[] { 15, 15 });

        Assert.True(problem.IsBalanced);
        var balanced = problem.GetBalanced();

        Assert.Equal(FictitiousType.None, balanced.FictitiousType);
        Assert.Equal(2, balanced.Rows);
        Assert.Equal(2, balanced.Cols);
    }

    [Fact]
    public void OfertaSuperaDemanda_AgregaDestinoFicticioConCostoCero()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 4, 6 }, new double[] { 5, 3 } },
            supply: new double[] { 50, 40 },   // total 90
            demand: new double[] { 30, 40 });  // total 70 -> diferencia 20

        Assert.False(problem.IsBalanced);
        Assert.Equal(FictitiousType.Destination, problem.RequiredFictitious);

        var balanced = problem.GetBalanced();

        Assert.Equal(3, balanced.Cols); // se agregó una columna
        Assert.Equal(2, balanced.Rows);
        Assert.Equal(20, balanced.Demand[2]);
        Assert.True(balanced.IsFictitiousCol(2));
        Assert.All(Enumerable.Range(0, balanced.Rows), i => Assert.Equal(0, balanced.Costs[i][2]));
    }

    [Fact]
    public void DemandaSuperaOferta_AgregaOrigenFicticioConCostoCero()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 4, 6, 8 } },
            supply: new double[] { 50 },              // total 50
            demand: new double[] { 30, 30, 30 });      // total 90 -> diferencia 40

        Assert.Equal(FictitiousType.Origin, problem.RequiredFictitious);

        var balanced = problem.GetBalanced();

        Assert.Equal(2, balanced.Rows); // se agregó una fila
        Assert.Equal(40, balanced.Supply[1]);
        Assert.True(balanced.IsFictitiousRow(1));
        Assert.All(Enumerable.Range(0, balanced.Cols), j => Assert.Equal(0, balanced.Costs[1][j]));
    }
}
