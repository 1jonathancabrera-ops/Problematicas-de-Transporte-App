using TransporteMAUI.Algorithms;
using TransporteMAUI.Models;
using Xunit;

namespace TransporteMAUI.Tests;

public class NorthwestCornerMethodTests
{
    private readonly NorthwestCornerMethod _method = new();

    [Fact]
    public void ProblemaBalanceado_AsignaEnDiagonalCorrecta()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 4, 6, 8 }, new double[] { 5, 3, 7 }, new double[] { 9, 4, 2 } },
            supply: new double[] { 50, 40, 60 },
            demand: new double[] { 30, 70, 50 });

        var solution = _method.Solve(problem);

        Assert.Equal("Esquina Noroeste", solution.MethodName);
        SolutionAssertions.AssertFeasible(solution, problem.GetBalanced());

        // La esquina noroeste empieza siempre en (0,0) con min(oferta[0], demanda[0]) = min(50,30) = 30
        Assert.Equal(30, solution.GetCell(0, 0).Quantity);
    }

    [Fact]
    public void MatrizUnoPorUno_AsignaTodoEnLaUnicaCelda()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 7 } },
            supply: new double[] { 15 },
            demand: new double[] { 15 });

        var solution = _method.Solve(problem);

        Assert.Single(solution.Cells);
        Assert.Equal(15, solution.Cells[0].Quantity);
        Assert.Equal(105, solution.TotalCost); // 15 * 7
    }

    [Fact]
    public void ConValoresCero_NoRompeElAlgoritmo()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 1, 2 }, new double[] { 3, 4 } },
            supply: new double[] { 0, 30 },
            demand: new double[] { 10, 20 });

        var solution = _method.Solve(problem);

        SolutionAssertions.AssertFeasible(solution, problem.GetBalanced());
    }

    [Fact]
    public void OfertaMayorQueDemanda_IncluyeDestinoFicticioEnLaSolucion()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 4, 6 }, new double[] { 5, 3 } },
            supply: new double[] { 50, 40 },
            demand: new double[] { 30, 40 });

        var solution = _method.Solve(problem);

        Assert.Equal(FictitiousType.Destination, solution.FictitiousType);
        Assert.Equal(20, solution.FictitiousAmount);
        Assert.Contains(solution.Cells, c => c.IsFictitiousCol);
        SolutionAssertions.AssertFeasible(solution, problem.GetBalanced());
    }

    [Fact]
    public void MatrizMasGrande_4x5_ProduceSolucionFactible()
    {
        var costs = new[]
        {
            new double[] { 4, 8, 8, 3, 6 },
            new double[] { 6, 5, 3, 9, 2 },
            new double[] { 7, 4, 6, 2, 5 },
            new double[] { 3, 9, 1, 7, 4 }
        };
        var supply = new double[] { 40, 60, 50, 30 };
        var demand = new double[] { 30, 40, 50, 30, 30 }; // suma 180 == suma oferta

        var problem = new TransportationProblem(costs, supply, demand);
        var solution = _method.Solve(problem);

        SolutionAssertions.AssertFeasible(solution, problem.GetBalanced());
    }
}
