using TransporteMAUI.Algorithms;
using TransporteMAUI.Models;
using Xunit;

namespace TransporteMAUI.Tests;

public class LeastCostMethodTests
{
    private readonly LeastCostMethod _method = new();

    [Fact]
    public void ProblemaBalanceado_EligeSiempreElMenorCostoDisponible()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 4, 6, 8 }, new double[] { 5, 3, 7 }, new double[] { 9, 4, 2 } },
            supply: new double[] { 50, 40, 60 },
            demand: new double[] { 30, 70, 50 });

        var solution = _method.Solve(problem);

        SolutionAssertions.AssertFeasible(solution, problem.GetBalanced());
        // El costo mínimo global es 2 en (2,2): debe usarse al máximo posible = min(60,50) = 50
        Assert.Equal(50, solution.GetCell(2, 2).Quantity);
    }

    [Fact]
    public void EmpateDeCostos_EligeLaCeldaDeMenorFilaYColumna()
    {
        // Costo 1 aparece en (0,1) y (1,0): por regla de empate documentada,
        // debe elegirse primero (0,1) (menor fila).
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 5, 1 }, new double[] { 1, 5 } },
            supply: new double[] { 10, 10 },
            demand: new double[] { 10, 10 });

        var solution = _method.Solve(problem);

        SolutionAssertions.AssertFeasible(solution, problem.GetBalanced());
        Assert.Equal(10, solution.GetCell(0, 1).Quantity);
    }

    [Fact]
    public void DemandaMayorQueOferta_IncluyeOrigenFicticio()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 4, 6, 8 } },
            supply: new double[] { 50 },
            demand: new double[] { 30, 30, 30 });

        var solution = _method.Solve(problem);

        Assert.Equal(FictitiousType.Origin, solution.FictitiousType);
        Assert.Contains(solution.Cells, c => c.IsFictitiousRow);
        SolutionAssertions.AssertFeasible(solution, problem.GetBalanced());
    }

    [Fact]
    public void FilaYColumnaSatisfechasAlMismoTiempo_NoRompeElAlgoritmo()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 2, 3 }, new double[] { 4, 1 } },
            supply: new double[] { 10, 10 },
            demand: new double[] { 10, 10 });

        var solution = _method.Solve(problem);

        SolutionAssertions.AssertFeasible(solution, problem.GetBalanced());
    }
}
