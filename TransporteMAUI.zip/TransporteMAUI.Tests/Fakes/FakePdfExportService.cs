using TransporteMAUI.Models;
using TransporteMAUI.Services;

namespace TransporteMAUI.Tests.Fakes;

/// <summary>Doble de prueba de <see cref="IPdfExportService"/>: no genera ningún PDF real.</summary>
public class FakePdfExportService : IPdfExportService
{
    public string[]? LastRowLabels { get; private set; }
    public string[]? LastColLabels { get; private set; }
    public int CallCount { get; private set; }

    public string Export(TransportationProject project, TransportationSolution? solution, string fileName,
        string[]? rowLabels = null, string[]? colLabels = null)
    {
        CallCount++;
        LastRowLabels = rowLabels;
        LastColLabels = colLabels;
        return $"C:\\fake\\{fileName}";
    }
}
