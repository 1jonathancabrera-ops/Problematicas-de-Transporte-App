using TransporteMAUI.Models;
using TransporteMAUI.Services;

namespace TransporteMAUI.Tests.Fakes;

/// <summary>Doble de prueba de <see cref="IProjectFileService"/>: no toca el disco real.</summary>
public class FakeProjectFileService : IProjectFileService
{
    /// <summary>Resultado que devuelve SaveAsAsync la próxima vez (null = "el usuario canceló").</summary>
    public string? NextSavePath { get; set; } = "C:\\fake\\proyecto.transp.json";

    /// <summary>Proyecto que devuelve OpenAsync la próxima vez (null = "el usuario canceló").</summary>
    public TransportationProject? NextOpenedProject { get; set; }

    public int ShareCallCount { get; private set; }
    public string? LastSharedPath { get; private set; }

    public Task<string?> SaveAsAsync(TransportationProject project) => Task.FromResult(NextSavePath);

    public Task ShareAsync(string filePath, string title = "Compartir proyecto")
    {
        ShareCallCount++;
        LastSharedPath = filePath;
        return Task.CompletedTask;
    }

    public Task<TransportationProject?> OpenAsync() => Task.FromResult(NextOpenedProject);
}
