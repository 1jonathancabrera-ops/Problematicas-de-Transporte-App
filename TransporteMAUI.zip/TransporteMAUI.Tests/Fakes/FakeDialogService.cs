using TransporteMAUI.Services;

namespace TransporteMAUI.Tests.Fakes;

/// <summary>Doble de prueba de <see cref="IDialogService"/>: no muestra ningún diálogo real.</summary>
public class FakeDialogService : IDialogService
{
    public List<string> Alerts { get; } = new();

    /// <summary>Valor que devuelve ConfirmAsync la próxima vez que se lo llame (default: true).</summary>
    public bool NextConfirmResult { get; set; } = true;

    public Task AlertAsync(string title, string message, string accept = "Aceptar")
    {
        Alerts.Add($"{title}: {message}");
        return Task.CompletedTask;
    }

    public Task<bool> ConfirmAsync(string title, string message, string accept, string cancel) =>
        Task.FromResult(NextConfirmResult);
}
