using TransporteMAUI.Services;

namespace TransporteMAUI.Tests.Fakes;

/// <summary>Doble de prueba de <see cref="INavigationService"/>: no navega de verdad, solo
/// registra qué se pidió, para poder verificarlo en los tests.</summary>
public class FakeNavigationService : INavigationService
{
    public List<(string Route, IDictionary<string, object>? Parameters)> Calls { get; } = new();

    public string? LastRoute => Calls.Count > 0 ? Calls[^1].Route : null;

    public Task GoToAsync(string route)
    {
        Calls.Add((route, null));
        return Task.CompletedTask;
    }

    public Task GoToAsync(string route, IDictionary<string, object> parameters)
    {
        Calls.Add((route, parameters));
        return Task.CompletedTask;
    }
}
