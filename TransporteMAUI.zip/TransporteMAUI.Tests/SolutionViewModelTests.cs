using TransporteMAUI.Algorithms;
using TransporteMAUI.Models;
using TransporteMAUI.Tests.Fakes;
using TransporteMAUI.ViewModels;
using Xunit;

namespace TransporteMAUI.Tests;

public class SolutionViewModelTests
{
    private static readonly ITransportationMethod[] AllMethods =
        { new NorthwestCornerMethod(), new LeastCostMethod(), new VogelMethod() };

    private static (SolutionViewModel vm, FakePdfExportService pdf, FakeProjectFileService files) Build(
        TransportationSolution solution, TransportationProject project,
        bool preloaded = false, ITransportationMethod[]? methods = null)
    {
        var pdf = new FakePdfExportService();
        var files = new FakeProjectFileService();
        var main = new MainViewModel(
            methods ?? new ITransportationMethod[] { new NorthwestCornerMethod() },
            files, pdf, new FakeNavigationService(), new FakeDialogService())
        {
            CurrentProject = project,
            CurrentSolution = solution,
            SolutionWasPreloaded = preloaded
        };

        var vm = new SolutionViewModel(main, new FakeNavigationService());
        return (vm, pdf, files);
    }

    private static (TransportationSolution solution, TransportationProject project) SolveSimpleProblem()
    {
        var problem = new TransportationProblem(
            costs: new[] { new double[] { 4, 6 }, new double[] { 5, 3 } },
            supply: new double[] { 10, 10 },
            demand: new double[] { 10, 10 });

        var solution = new NorthwestCornerMethod().Solve(problem);
        var project = TransportationProject.FromProblem(problem, "Proyecto de prueba");
        return (solution, project);
    }

    [Fact]
    public void Construccion_ArmaFilasYColumnasSegunLaSolucion()
    {
        var (solution, project) = SolveSimpleProblem();
        var (vm, _, _) = Build(solution, project);

        Assert.Equal(2, vm.Rows.Count);
        Assert.Equal(2, vm.Columns.Count);
        Assert.Equal("O1", vm.Rows[0].Label);
        Assert.Equal("D1", vm.Columns[0].Label);
    }

    [Fact]
    public async Task ExportPdf_UsaLasEtiquetasRenombradasEnPantalla()
    {
        var (solution, project) = SolveSimpleProblem();
        var (vm, pdf, _) = Build(solution, project);

        // El usuario renombra "O1" a un nombre propio antes de exportar.
        vm.Rows[0].Label = "Depósito Norte";
        vm.Columns[1].Label = "Sucursal Sur";

        await vm.ExportPdfCommand.ExecuteAsync(null);

        Assert.Equal(1, pdf.CallCount);
        Assert.NotNull(pdf.LastRowLabels);
        Assert.NotNull(pdf.LastColLabels);
        Assert.Equal("Depósito Norte", pdf.LastRowLabels![0]);
        Assert.Equal("Sucursal Sur", pdf.LastColLabels![1]);
    }

    [Fact]
    public void CalculateCost_RevelaElDesgloseDeCosto()
    {
        var (solution, project) = SolveSimpleProblem();
        var (vm, _, _) = Build(solution, project);

        Assert.False(vm.ShowCostBreakdown);
        vm.CalculateCostCommand.Execute(null);
        Assert.True(vm.ShowCostBreakdown);
    }

    [Fact]
    public void SolucionRecienResuelta_ElCostoArrancaOculto()
    {
        var (solution, project) = SolveSimpleProblem();
        var (vm, _, _) = Build(solution, project, preloaded: false);

        Assert.False(vm.ShowCostBreakdown);
    }

    [Fact]
    public void SolucionDeProyectoReabierto_ElCostoArrancaYaRevelado()
    {
        var (solution, project) = SolveSimpleProblem();
        var (vm, _, _) = Build(solution, project, preloaded: true);

        Assert.True(vm.ShowCostBreakdown);
    }

    [Fact]
    public void MethodComparison_IncluyeLosTresMetodosYMarcaElMasBarato()
    {
        var (solution, project) = SolveSimpleProblem();
        var (vm, _, _) = Build(solution, project, methods: AllMethods);

        Assert.Equal(3, vm.MethodComparison.Count);
        Assert.Contains(vm.MethodComparison, r => r.Name == "Esquina Noroeste");
        Assert.Contains(vm.MethodComparison, r => r.Name == "Menor Costo");
        Assert.Contains(vm.MethodComparison, r => r.Name == "Vogel");

        // Al menos uno tiene que quedar marcado como el más barato.
        Assert.Contains(vm.MethodComparison, r => r.IsBest);

        var costos = vm.MethodComparison.Select(r => double.Parse(r.CostText)).ToList();
        var mejores = vm.MethodComparison.Where(r => r.IsBest).Select(r => double.Parse(r.CostText));
        Assert.All(mejores, c => Assert.Equal(costos.Min(), c, precision: 6));
    }
}

