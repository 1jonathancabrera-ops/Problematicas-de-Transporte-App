using System.Text.Json;
using CommunityToolkit.Maui.Storage;
using TransporteMAUI.Models;

namespace TransporteMAUI.Services;

/// <summary>
/// Guarda y abre proyectos (.json propio de la aplicación) usando los diálogos nativos
/// del sistema operativo: FileSaver (CommunityToolkit.Maui) para "Guardar como", y
/// FilePicker (MAUI Essentials) para "Abrir".
/// </summary>
public class ProjectFileService : IProjectFileService
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    public const string FileExtension = ".transp.json";

    /// <summary>Serializa el proyecto a texto JSON.</summary>
    private string Serialize(TransportationProject project)
    {
        project.LastModified = DateTime.Now;
        return JsonSerializer.Serialize(project, JsonOptions);
    }

    /// <summary>Intenta deserializar el contenido de un archivo de proyecto. Lanza si el formato es inválido.</summary>
    private TransportationProject Deserialize(string json)
    {
        var project = JsonSerializer.Deserialize<TransportationProject>(json, JsonOptions)
            ?? throw new InvalidDataException("El archivo de proyecto está vacío o corrupto.");

        Validate(project);
        return project;
    }

    /// <summary>
    /// Valida la coherencia mínima del proyecto abierto (dimensiones, valores no negativos)
    /// para no dejar caer la aplicación con un archivo inválido.
    /// </summary>
    private void Validate(TransportationProject project)
    {
        if (project.Costs is null || project.Supply is null || project.Demand is null)
            throw new InvalidDataException("El archivo de proyecto no contiene una matriz válida.");

        if (project.Supply.Length != project.OriginCount || project.Demand.Length != project.DestinationCount)
            throw new InvalidDataException("Las dimensiones del proyecto no coinciden con los datos guardados.");

        if (project.Costs.Length != project.OriginCount || project.Costs.Any(row => row.Length != project.DestinationCount))
            throw new InvalidDataException("La matriz de costos del proyecto está corrupta.");

        if (project.Supply.Any(v => v < 0) || project.Demand.Any(v => v < 0) ||
            project.Costs.Any(row => row.Any(v => v < 0)))
            throw new InvalidDataException("El archivo de proyecto contiene valores negativos no válidos.");
    }

    /// <summary>
    /// Abre el diálogo nativo "Guardar como" del sistema operativo para que el usuario
    /// elija dónde guardar el proyecto. Devuelve la ruta final, o null si el usuario
    /// canceló el diálogo. Lanza excepción si falló por otro motivo (ver <see cref="FileSaverResult.Exception"/>).
    /// </summary>
    public async Task<string?> SaveAsAsync(TransportationProject project)
    {
        var json = Serialize(project);
        var fileName = $"{SanitizeFileName(project.Name)}{FileExtension}";

        using var stream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(json));
        var result = await FileSaver.Default.SaveAsync(fileName, stream, CancellationToken.None);

        if (result.IsSuccessful) return result.FilePath;

        // FileSaver reporta la cancelación del diálogo como una excepción (no simplemente
        // IsSuccessful=false sin más), así que hay que distinguirla de un error real para
        // no mostrarle al usuario "No se pudo guardar" cuando en realidad canceló él mismo.
        if (result.Exception is OperationCanceledException ||
            (result.Exception?.Message?.Contains("cancel", StringComparison.OrdinalIgnoreCase) ?? false))
            return null;

        if (result.Exception is not null) throw result.Exception;
        return null; // el usuario cerró/canceló el diálogo sin elegir una ubicación
    }

    /// <summary>Ofrece compartir/exportar un archivo ya guardado usando el diálogo nativo del sistema.</summary>
    public async Task ShareAsync(string filePath, string title = "Compartir proyecto")
    {
        await Share.Default.RequestAsync(new ShareFileRequest
        {
            Title = title,
            File = new ShareFile(filePath)
        });
    }

    /// <summary>Abre un proyecto eligiendo el archivo con el selector nativo. Devuelve null si se canceló.</summary>
    public async Task<TransportationProject?> OpenAsync()
    {
        var fileType = new FilePickerFileType(new Dictionary<DevicePlatform, IEnumerable<string>>
        {
            { DevicePlatform.WinUI, new[] { ".json" } },
            { DevicePlatform.MacCatalyst, new[] { "json" } },
            { DevicePlatform.Android, new[] { "application/json" } },
            { DevicePlatform.iOS, new[] { "public.json" } }
        });

        var options = new PickOptions
        {
            PickerTitle = "Abrir proyecto de transporte",
            FileTypes = fileType
        };

        var result = await FilePicker.Default.PickAsync(options);
        if (result is null) return null;

        var json = await File.ReadAllTextAsync(result.FullPath);
        return Deserialize(json);
    }

    private static string SanitizeFileName(string name)
    {
        var invalid = Path.GetInvalidFileNameChars();
        var clean = new string(name.Where(c => !invalid.Contains(c)).ToArray()).Trim();
        return string.IsNullOrWhiteSpace(clean) ? "proyecto" : clean;
    }
}
