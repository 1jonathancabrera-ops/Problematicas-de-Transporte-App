namespace TransporteMAUI.Services;

/// <summary>Implementación real de <see cref="INavigationService"/>, usando el Shell de MAUI.</summary>
public class ShellNavigationService : INavigationService
{
    public Task GoToAsync(string route) => Shell.Current.GoToAsync(route);

    public Task GoToAsync(string route, IDictionary<string, object> parameters) =>
        Shell.Current.GoToAsync(route, parameters);
}
