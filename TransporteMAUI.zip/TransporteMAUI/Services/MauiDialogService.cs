namespace TransporteMAUI.Services;

/// <summary>Implementación real de <see cref="IDialogService"/>, usando DisplayAlertAsync de MAUI.</summary>
public class MauiDialogService : IDialogService
{
    public Task AlertAsync(string title, string message, string accept = "Aceptar")
    {
        var page = CurrentPage();
        return page is not null ? page.DisplayAlertAsync(title, message, accept) : Task.CompletedTask;
    }

    public async Task<bool> ConfirmAsync(string title, string message, string accept, string cancel)
    {
        var page = CurrentPage();
        return page is not null && await page.DisplayAlertAsync(title, message, accept, cancel);
    }

    private static Page? CurrentPage() =>
        Application.Current?.Windows.Count > 0 ? Application.Current.Windows[0].Page : null;
}
