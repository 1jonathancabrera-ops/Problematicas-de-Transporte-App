using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using TransporteMAUI.Models;
// En un proyecto MAUI, Microsoft.Maui.Graphics también define un IContainer y una clase
// Colors (quedan en scope por los usings implícitos del SDK) y chocan con los homónimos de
// QuestPDF.Infrastructure/QuestPDF.Helpers. Se desambiguan con alias explícitos.
using IContainer = QuestPDF.Infrastructure.IContainer;
using Colors = QuestPDF.Helpers.Colors;

namespace TransporteMAUI.Services;

/// <summary>
/// Genera un informe PDF académico/profesional de un problema de transporte resuelto,
/// usando QuestPDF (librería .NET pura, multiplataforma y con licencia Community gratuita
/// para uso no comercial, ideal para un proyecto académico en .NET MAUI).
/// </summary>
public class PdfExportService : IPdfExportService
{
    /// <summary>Genera el PDF con el nombre sugerido en la carpeta de caché de la app y devuelve la ruta final.</summary>
    public string Export(TransportationProject project, TransportationSolution? solution, string fileName,
        string[]? rowLabels = null, string[]? colLabels = null)
    {
        var filePath = Path.Combine(FileSystem.CacheDirectory, fileName);

        var document = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(35);
                page.DefaultTextStyle(x => x.FontSize(11));

                page.Header().Column(col =>
                {
                    col.Item().Text("Informe — Problema de Transporte").FontSize(20).Bold();
                    col.Item().Text(project.Name).FontSize(14).FontColor(Colors.Grey.Darken2);
                    col.Item().PaddingTop(2).Text($"Generado: {DateTime.Now:dd/MM/yyyy HH:mm}").FontSize(9).FontColor(Colors.Grey.Medium);
                    col.Item().PaddingTop(6).LineHorizontal(1).LineColor(Colors.Grey.Lighten1);
                });

                page.Content().PaddingTop(15).Column(col =>
                {
                    col.Spacing(12);

                    col.Item().Text(text =>
                    {
                        text.Span("Método utilizado: ").SemiBold();
                        text.Span(solution?.MethodName ?? project.MethodUsed ?? "(no resuelto)");
                    });

                    col.Item().Text(text =>
                    {
                        text.Span("Orígenes: ").SemiBold();
                        text.Span(project.OriginCount.ToString());
                        text.Span("     Destinos: ").SemiBold();
                        text.Span(project.DestinationCount.ToString());
                    });

                    bool balanceado = solution?.WasBalancedOriginally ?? (project.Supply.Sum() == project.Demand.Sum());
                    col.Item().Text(text =>
                    {
                        text.Span("Estado original: ").SemiBold();
                        text.Span(balanceado ? "Problema balanceado" : "Problema no balanceado");
                    });

                    if (solution is { FictitiousType: not FictitiousType.None })
                    {
                        var etiqueta = solution.FictitiousType == FictitiousType.Origin ? "Origen ficticio" : "Destino ficticio";
                        col.Item().Text($"{etiqueta} agregado: {solution.FictitiousAmount:0.##} unidades")
                            .FontColor(Colors.Grey.Darken2);
                    }

                    col.Item().PaddingTop(6).Text("Matriz de costos ingresada").Bold().FontSize(13);
                    col.Item().Element(c => ComposeCostMatrix(c, project));

                    if (solution is not null)
                    {
                        col.Item().PaddingTop(10).Text("Tabla de solución").Bold().FontSize(13);
                        col.Item().Element(c => ComposeSolutionTable(c, solution, rowLabels, colLabels));

                        col.Item().PaddingTop(10).Text("Cálculo del costo total").Bold().FontSize(13);
                        col.Item().Text(string.Join("  +  ", solution.CostExpressionTerms));
                        col.Item().PaddingTop(4).Text($"Costo total = {solution.TotalCost:0.##}").FontSize(14).Bold();
                    }
                });

                page.Footer().AlignCenter().Text(text =>
                {
                    text.CurrentPageNumber();
                    text.Span(" / ");
                    text.TotalPages();
                });
            });
        });

        document.GeneratePdf(filePath);
        return filePath;
    }

    private static void ComposeCostMatrix(IContainer container, TransportationProject p)
    {
        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.ConstantColumn(70);
                for (int j = 0; j < p.DestinationCount; j++) columns.RelativeColumn();
                columns.ConstantColumn(60);
            });

            table.Header(header =>
            {
                header.Cell().Element(HeaderStyle).Text("");
                for (int j = 0; j < p.DestinationCount; j++)
                    header.Cell().Element(HeaderStyle).Text($"D{j + 1}");
                header.Cell().Element(HeaderStyle).Text("Oferta");
            });

            for (int i = 0; i < p.OriginCount; i++)
            {
                table.Cell().Element(HeaderStyle).Text($"O{i + 1}");
                for (int j = 0; j < p.DestinationCount; j++)
                    table.Cell().Element(CellStyle).Text(p.Costs[i][j].ToString("0.##"));
                table.Cell().Element(CellStyle).Text(p.Supply[i].ToString("0.##"));
            }

            table.Cell().Element(HeaderStyle).Text("Demanda");
            for (int j = 0; j < p.DestinationCount; j++)
                table.Cell().Element(CellStyle).Text(p.Demand[j].ToString("0.##"));
            table.Cell().Element(CellStyle).Text("");
        });
    }

    private static void ComposeSolutionTable(IContainer container, TransportationSolution s, string[]? rowLabels, string[]? colLabels)
    {
        // Si el usuario renombró alguna etiqueta en la pantalla de resultados, se usa esa;
        // si no hay etiquetas personalizadas (o no alcanzan para esta dimensión), se cae al
        // nombre por defecto "O{i+1}"/"D{j+1}" (o "Fict." si esa fila/columna es ficticia).
        string RowLabel(int i, bool esFicticia) =>
            rowLabels is { } arr && i < arr.Length ? arr[i] : (esFicticia ? "Or. Fict." : $"O{i + 1}");

        string ColLabel(int j, bool esFicticia) =>
            colLabels is { } arr && j < arr.Length ? arr[j] : (esFicticia ? "Dest. Fict." : $"D{j + 1}");

        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.ConstantColumn(70);
                for (int j = 0; j < s.Cols; j++) columns.RelativeColumn();
                columns.ConstantColumn(60);
            });

            table.Header(header =>
            {
                header.Cell().Element(HeaderStyle).Text("");
                for (int j = 0; j < s.Cols; j++)
                {
                    var esFicticia = s.Cells.Any(c => c.Col == j && c.IsFictitiousCol);
                    header.Cell().Element(HeaderStyle).Text(ColLabel(j, esFicticia));
                }
                header.Cell().Element(HeaderStyle).Text("Oferta");
            });

            for (int i = 0; i < s.Rows; i++)
            {
                var filaFicticia = s.Cells.Any(c => c.Row == i && c.IsFictitiousRow);
                table.Cell().Element(HeaderStyle).Text(RowLabel(i, filaFicticia));

                for (int j = 0; j < s.Cols; j++)
                {
                    var cell = s.GetCell(i, j);
                    table.Cell().Element(cell.IsUsed ? UsedCellStyle : CellStyle).Text(cell.Display);
                }
                table.Cell().Element(CellStyle).Text(s.SupplyRowTotal(i).ToString("0.##"));
            }

            table.Cell().Element(HeaderStyle).Text("Demanda");
            for (int j = 0; j < s.Cols; j++)
                table.Cell().Element(CellStyle).Text(s.DemandColTotal(j).ToString("0.##"));
            table.Cell().Element(CellStyle).Text("");
        });
    }

    private static IContainer HeaderStyle(IContainer c) => c
        .Background(Colors.Grey.Lighten3)
        .Border(1).BorderColor(Colors.Grey.Lighten1)
        .Padding(5).AlignCenter();

    private static IContainer CellStyle(IContainer c) => c
        .Border(1).BorderColor(Colors.Grey.Lighten1)
        .Padding(5).AlignCenter();

    private static IContainer UsedCellStyle(IContainer c) => c
        .Background(Colors.Green.Lighten4)
        .Border(1).BorderColor(Colors.Green.Medium)
        .Padding(5).AlignCenter();
}
