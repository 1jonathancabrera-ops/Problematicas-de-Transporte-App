using TransporteMAUI.ViewModels;

namespace TransporteMAUI.Views;

public partial class NewProjectGalleryPage : ContentPage
{
    public NewProjectGalleryPage(MainViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
