using TransporteMAUI.Navigation;

namespace TransporteMAUI.Views;

public partial class SplashPage : ContentPage
{
    private readonly TaskCompletionSource _skipped = new();

    public SplashPage()
    {
        InitializeComponent();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        // El delay es puramente cosmético (branding), no está esperando ningún trabajo
        // real — para no dejar a nadie mirando la pantalla sin motivo en una máquina
        // lenta, un toque en cualquier lado la salta al instante.
        await Task.WhenAny(Task.Delay(1400), _skipped.Task);
        await Shell.Current.GoToAsync($"//{Routes.MainPage}");
    }

    private void OnSkipTapped(object? sender, TappedEventArgs e) => _skipped.TrySetResult();
}
