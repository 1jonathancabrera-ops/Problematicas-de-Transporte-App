using CommunityToolkit.Mvvm.Messaging;
using TransporteMAUI.Services;
using TransporteMAUI.ViewModels;

namespace TransporteMAUI.Views;

public partial class NewProblemPage : ContentPage, IQueryAttributable
{
    private readonly NewProblemViewModel _viewModel;

    public NewProblemPage(NewProblemViewModel viewModel)
    {
        InitializeComponent();
        _viewModel = viewModel;
        BindingContext = viewModel;
    }

    /// <summary>
    /// IQueryAttributable es de Microsoft.Maui.Controls, así que no puede vivir en el
    /// ViewModel (que está en TransporteMAUI.Core, sin esa dependencia). Shell navega
    /// pasándole los parámetros a la página; acá se los reenvía al ViewModel a través de
    /// IQueryParameterReceiver (la interfaz propia que sí puede implementar).
    /// </summary>
    public void ApplyQueryAttributes(IDictionary<string, object> query)
    {
        if (_viewModel is IQueryParameterReceiver receiver)
            receiver.ApplyQueryAttributes(query);
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        WeakReferenceMessenger.Default.Register<TableGeneratedMessage>(this, (recipient, message) =>
        {
            var (origins, destinations) = message.Value;
            MainThread.BeginInvokeOnMainThread(() => BuildMatrixGrid(origins, destinations));
        });

        // Si el ViewModel ya tenía una tabla generada (ej. al volver de "Solución" o al
        // abrir un proyecto existente), la mensajería pudo haberse enviado antes de que
        // esta página se suscribiera, así que la construimos también acá directamente.
        if (_viewModel.TableGenerated)
            BuildMatrixGrid(_viewModel.OriginCount, _viewModel.DestinationCount);
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        WeakReferenceMessenger.Default.Unregister<TableGeneratedMessage>(this);
    }

    /// <summary>
    /// Reconstruye la grilla de COSTOS únicamente: encabezado de columnas (D1..Dn),
    /// una fila por origen (O1..Om) con exactamente <paramref name="destinations"/>
    /// celdas de costo cada una. Ofertas y demandas se muestran aparte (ver
    /// NewProblemPage.xaml), no se mezclan en esta grilla.
    /// Equivale a generarInputs() de la versión web, pero como controles nativos.
    /// </summary>
    private void BuildMatrixGrid(int origins, int destinations)
    {
        MatrixHost.Children.Clear();
        MatrixHost.RowDefinitions.Clear();
        MatrixHost.ColumnDefinitions.Clear();

        if (origins <= 0 || destinations <= 0) return;

        int totalRows = origins + 1;      // encabezado + una fila por origen
        int totalCols = destinations + 1; // etiqueta + una columna por destino

        for (int r = 0; r < totalRows; r++) MatrixHost.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        for (int c = 0; c < totalCols; c++) MatrixHost.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));

        // Encabezado de columnas
        AddHeaderLabel("", 0, 0);
        for (int j = 0; j < destinations; j++)
            AddHeaderLabel($"D{j + 1}", 0, j + 1);

        // Filas de orígenes: etiqueta + exactamente "destinations" celdas de costo
        for (int i = 0; i < origins; i++)
        {
            AddHeaderLabel($"O{i + 1}", i + 1, 0);

            for (int j = 0; j < destinations; j++)
            {
                var cell = _viewModel.CostCells[i * destinations + j];
                AddEntry(cell, i + 1, j + 1);
            }
        }

        void AddHeaderLabel(string text, int row, int col)
        {
            var label = new Label
            {
                Text = text,
                FontAttributes = FontAttributes.Bold,
                HorizontalTextAlignment = TextAlignment.Center,
                VerticalTextAlignment = TextAlignment.Center,
                Padding = new Thickness(6),
                MinimumWidthRequest = 64
            };
            MatrixHost.Add(label, col, row);
        }

        void AddEntry(EditableValue value, int row, int col)
        {
            var entry = new Entry
            {
                BindingContext = value,
                Keyboard = Keyboard.Numeric,
                WidthRequest = 64,
                HeightRequest = 38,
                HorizontalTextAlignment = TextAlignment.Center,
                BackgroundColor = (Color)Application.Current!.Resources["SurfaceCard"]
            };
            entry.SetBinding(Entry.TextProperty, new Binding(nameof(EditableValue.Text)));
            MatrixHost.Add(entry, col, row);
        }
    }
}
