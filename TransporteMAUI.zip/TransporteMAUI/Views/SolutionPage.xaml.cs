using TransporteMAUI.ViewModels;

namespace TransporteMAUI.Views;

public partial class SolutionPage : ContentPage
{
    public SolutionPage(SolutionViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
}
