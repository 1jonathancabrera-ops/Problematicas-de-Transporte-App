using Microsoft.UI.Xaml;
using TransporteMAUI;

// Para saber más sobre el modelo de aplicaciones empaquetadas y desempaquetadas de WinUI 3, ver:
// https://docs.microsoft.com/windows/apps/desktop/modernize/desktop-to-uwp-packaging-options

namespace TransporteMAUI.WinUI;

/// <summary>
/// Punto de entrada nativo de Windows (WinUI 3). Solo delega en MauiProgram; toda la
/// lógica de la aplicación vive en el proyecto compartido (App.xaml en la raíz).
/// </summary>
public partial class App : MauiWinUIApplication
{
    public App()
    {
        this.InitializeComponent();
    }

    protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
}
