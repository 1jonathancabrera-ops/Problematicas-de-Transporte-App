using ObjCRuntime;
using UIKit;

namespace TransporteMAUI;

public class Program
{
    static void Main(string[] args)
    {
        UIApplication.Main(args, null, typeof(AppDelegate));
    }
}
