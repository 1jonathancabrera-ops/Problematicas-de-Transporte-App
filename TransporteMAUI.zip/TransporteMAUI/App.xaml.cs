namespace TransporteMAUI;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        var window = new Window(new AppShell())
        {
            Title = "Problema de Transporte",
            Width = 1200,
            Height = 800,
            MinimumWidth = 900,
            MinimumHeight = 600
        };
        return window;
    }
}
