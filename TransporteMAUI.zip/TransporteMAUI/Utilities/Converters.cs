using System.Globalization;

namespace TransporteMAUI.Utilities;

/// <summary>Convierte entre el texto de un Entry y un entero, para bindear cantidades (orígenes/destinos).</summary>
public class StringToIntConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => value is int i ? i.ToString(CultureInfo.InvariantCulture) : "0";

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => int.TryParse(value as string, NumberStyles.Integer, CultureInfo.InvariantCulture, out var result) && result >= 0
            ? result
            : 0;
}

/// <summary>Invierte un booleano; útil para habilitar/deshabilitar controles según el estado inverso de una propiedad.</summary>
public class InverseBoolConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => value is bool b && !b;

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => value is bool b && !b;
}

/// <summary>Devuelve TrueColor o FalseColor según un booleano. Los colores se configuran como
/// propiedades del converter en el XAML donde se declara la instancia (ver BestCostColorConverter en App.xaml).</summary>
public class BoolToColorConverter : IValueConverter
{
    public Color TrueColor { get; set; } = Colors.Green;
    public Color FalseColor { get; set; } = Colors.Black;

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => value is bool b && b ? TrueColor : FalseColor;

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}

/// <summary>
/// Convierte el "IsFinal" de una celda de penalización (bool, definido en Core sin
/// depender de MAUI) al TextDecorations real que tacha el texto en pantalla.
/// </summary>
public class BoolToTextDecorationConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => value is true ? TextDecorations.Strikethrough : TextDecorations.None;

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
