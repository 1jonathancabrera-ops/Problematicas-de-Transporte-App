using TransporteMAUI.Navigation;
using TransporteMAUI.Views;

namespace TransporteMAUI;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();

        Routing.RegisterRoute(Routes.NewProblemPage, typeof(NewProblemPage));
        Routing.RegisterRoute(Routes.NewProjectGalleryPage, typeof(NewProjectGalleryPage));
        Routing.RegisterRoute(Routes.SolutionPage, typeof(SolutionPage));
        Routing.RegisterRoute(Routes.HelpPage, typeof(HelpPage));
    }
}
