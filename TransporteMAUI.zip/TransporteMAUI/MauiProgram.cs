using Microsoft.Extensions.Logging;
using TransporteMAUI.Algorithms;
using TransporteMAUI.Services;
using TransporteMAUI.ViewModels;
using TransporteMAUI.Views;
using QuestPDF.Infrastructure;
using CommunityToolkit.Maui;

namespace TransporteMAUI;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        // QuestPDF requiere licencia configurada; Community es gratuita para este uso académico.
        QuestPDF.Settings.License = LicenseType.Community;

        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .UseMauiCommunityToolkit() // requerido por FileSaver (diálogo nativo "Guardar como")
            .ConfigureFonts(fonts =>
            {
                // Instrument Sans para títulos/encabezados, Geist para el resto del texto.
                // Los .ttf están en Resources/Fonts.
                fonts.AddFont("InstrumentSans-SemiBold.ttf", "InstrumentSansSemibold");
                fonts.AddFont("Geist-Regular.ttf", "GeistRegular");
                fonts.AddFont("Geist-Medium.ttf", "GeistMedium");
            });

#if DEBUG
        builder.Logging.AddDebug();
#endif

        // ---- Algoritmos (estrategia intercambiable) ----
        // Registrar las tres implementaciones contra la interfaz alcanza para que el
        // contenedor de DI resuelva automáticamente un IEnumerable<ITransportationMethod>
        // con las tres (así se inyecta en MainViewModel/NewProblemViewModel).
        builder.Services.AddSingleton<ITransportationMethod, NorthwestCornerMethod>();
        builder.Services.AddSingleton<ITransportationMethod, LeastCostMethod>();
        builder.Services.AddSingleton<ITransportationMethod, VogelMethod>();

        // ---- Servicios ----
        // Se registran contra sus interfaces (definidas en TransporteMAUI.Core) para que
        // los ViewModels no dependan de las clases concretas ni de tipos de MAUI — así se
        // pueden instanciar en tests con implementaciones falsas (ver TransporteMAUI.Tests).
        builder.Services.AddSingleton<IProjectFileService, ProjectFileService>();
        builder.Services.AddSingleton<IPdfExportService, PdfExportService>();
        builder.Services.AddSingleton<INavigationService, ShellNavigationService>();
        builder.Services.AddSingleton<IDialogService, MauiDialogService>();

        // ---- ViewModels ----
        builder.Services.AddSingleton<MainViewModel>();
        builder.Services.AddTransient<NewProblemViewModel>();
        builder.Services.AddTransient<SolutionViewModel>();

        // ---- Vistas ----
        builder.Services.AddTransient<SplashPage>();
        builder.Services.AddSingleton<MainPage>();
        builder.Services.AddTransient<NewProblemPage>();
        builder.Services.AddTransient<NewProjectGalleryPage>();
        builder.Services.AddTransient<SolutionPage>();
        builder.Services.AddTransient<HelpPage>();

        return builder.Build();
    }
}
