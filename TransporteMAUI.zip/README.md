# Problema de Transporte — .NET MAUI

Migración de la versión web (HTML/CSS/JS) a una aplicación de escritorio/multiplataforma
con **.NET MAUI + C# + XAML**, pensada como herramienta académica para practicar los
métodos de solución inicial del problema de transporte.

## Cómo abrir y compilar

1. Instalar el **workload de .NET MAUI** (Visual Studio **2026** con la carga de trabajo
   ".NET Multi-platform App UI development" — apuntar a `net10.0` requiere VS 2026, no
   alcanza con VS 2022).
2. Abrir `TransporteMAUI.sln` en Visual Studio (o `dotnet build` desde la carpeta raíz).
3. Elegir como proyecto de inicio **TransporteMAUI** y como framework de destino
   `net10.0-windows10.0.19041.0` (recomendado para desarrollo/demo en Windows).
4. F5 para ejecutar.

Para correr los tests unitarios:

```
dotnet test TransporteMAUI.Tests/TransporteMAUI.Tests.csproj
```

> Nota: este proyecto se generó en un entorno sin SDK de .NET disponible, por lo que el
> código no pudo compilarse automáticamente acá. Se revisó manualmente la sintaxis, los
> `using`, y la coherencia entre proyectos, pero se recomienda compilar en Visual Studio
> y resolver cualquier detalle menor (nombres de paquetes NuGet, versiones) antes de la
> entrega final.

## Estructura de la solución

```
TransporteMAUI.sln
├── TransporteMAUI/            → Cabecera MAUI (UI): Views, ViewModels, Services, Resources
├── TransporteMAUI.Core/       → Librería .NET pura: Models + Algorithms (sin dependencias de MAUI)
└── TransporteMAUI.Tests/      → Pruebas unitarias (xUnit) de los algoritmos y el balanceo
```

Separar `Models`/`Algorithms` en **TransporteMAUI.Core** permite:
- Testear la lógica matemática con xUnit sin necesidad de compilar para Android/iOS/Windows.
- Reutilizar el motor de cálculo desde otro front-end en el futuro (consola, web, etc.).

### TransporteMAUI (UI)

```
Models/, Algorithms/, ViewModels/  (viven en TransporteMAUI.Core, ver más abajo)
Services/
  ProjectFileService.cs      → implementa IProjectFileService: guardar/abrir/compartir
  PdfExportService.cs        → implementa IPdfExportService: informe PDF con QuestPDF
  ShellNavigationService.cs  → implementa INavigationService, usando Shell
  MauiDialogService.cs       → implementa IDialogService, usando DisplayAlertAsync
Views/
  MainPage.xaml            → Pantalla de inicio tipo Office (ribbon + accesos rápidos)
  NewProjectGalleryPage.xaml → Galería "Nuevo" estilo Word: plantillas (blanco + un tile por método)
  NewProblemPage.xaml(.cs) → Hoja de cálculo del problema (grilla armada en code-behind)
  SolutionPage.xaml        → Tabla resuelta de solo lectura + costo total
  HelpPage.xaml             → Ayuda orientada a estudiantes
  SplashPage.xaml           → Pantalla de bienvenida con degradé (tocable para saltear)
Resources/Styles/
  Colors.xaml, Styles.xaml → Paleta y estilos oscuro/dorado (ribbon, tarjetas, botones)
Utilities/
  Converters.cs            → StringToIntConverter, InverseBoolConverter, BoolToTextDecorationConverter
```

### TransporteMAUI.Core (dominio + ViewModels, sin dependencias de MAUI Controls)

```
Models/
  TransportationProblem.cs  → Problema tal como lo ingresa el usuario + balanceo automático
  TransportationSolution.cs → Resultado de un método (celdas, expresión de costo, total)
  CellAssignment.cs         → Una celda de la tabla resuelta
  TransportationProject.cs  → Unidad guardable/abrible en disco (JSON)
  VogelIterationSnapshot.cs → Historial de penalizaciones por iteración (solo Vogel)
Algorithms/
  ITransportationMethod.cs  → Estrategia común: Solve(TransportationProblem) → Solution
  NorthwestCornerMethod.cs
  LeastCostMethod.cs
  VogelMethod.cs
  SolutionBuilder.cs
Navigation/
  Routes.cs                 → Nombres de ruta compartidos (ViewModels y AppShell usan los mismos)
Services/ (interfaces solamente — las implementaciones concretas viven en TransporteMAUI)
  INavigationService.cs, IDialogService.cs
  IProjectFileService.cs, IPdfExportService.cs
ViewModels/
  MainViewModel.cs, NewProblemViewModel.cs, SolutionViewModel.cs
  EditableValue.cs, GalleryTile.cs, TableGeneratedMessage.cs
```

## Cómo funciona el balanceo automático

`TransportationProblem.GetBalanced()` centraliza la lógica de balanceo: si la oferta y la
demanda totales no coinciden, agrega automáticamente una fila (origen ficticio) o columna
(destino ficticio) con costo 0, y devuelve un `BalancedProblem` que es lo único que reciben
los tres algoritmos. Esto evita que cada método duplique la lógica de balanceo (como pasaba
en la versión web, donde `agregarFicticio()` mutaba directamente arrays sueltos).

En la UI, el botón "Agregar Ficticio" de `NewProblemViewModel` es ahora solo informativo:
como el balanceo se recalcula automáticamente antes de resolver, no hace falta mutar datos
a mano; el paso se conserva por claridad pedagógica (el estudiante ve explícitamente que
se va a agregar un elemento ficticio antes de resolver).

## Los tres algoritmos

Los tres implementan `ITransportationMethod` (`Solve(TransportationProblem) → TransportationSolution`),
lo que permite que la UI sea idéntica sin importar el método elegido y que agregar un cuarto
método en el futuro sea tan simple como escribir una clase nueva y registrarla en `MauiProgram.cs`.

- **Esquina Noroeste**: arranca en (0,0) y asigna `min(oferta, demanda)`, avanzando de fila
  o columna según cuál se agote primero.
- **Menor Costo**: en cada paso busca la celda disponible de menor costo y asigna el máximo
  posible. Regla de empate documentada en el código: se prioriza la celda de menor fila y
  luego menor columna.
- **Vogel (VAM)**: calcula penalizaciones (diferencia entre los dos costos más bajos) por
  fila y columna, elige la de mayor penalización y dentro de ella la celda de menor costo.
  Reglas de empate (penalización y costo) documentadas en `VogelMethod.cs`.

## Correcciones respecto a la versión web original

Al migrar se detectaron y corrigieron los siguientes puntos (conservando el resto del
comportamiento tal cual estaba):

1. **Esquina Noroeste — avance simultáneo de fila y columna.** En el JS original, cuando
   una asignación dejaba en 0 tanto la oferta de la fila como la demanda de la columna al
   mismo tiempo (antes de la última celda), el código solo avanzaba la fila (`if (oferta[i]
   === 0) i++`), dejando la columna con demanda 0 pendiente de visitar en el siguiente
   paso. Funcionalmente no rompía el resultado final porque esa columna terminaba
   asignándose en 0 de todos modos, pero era ambiguo. Se documentó y explicitó la regla:
   si ambas llegan a 0 simultáneamente, se avanza fila y columna a la vez.
2. **Balanceo centralizado.** La versión web recalculaba el balanceo por separado en cada
   archivo (`Esquina_N.js` y `MenorCosto.js`), duplicando la lógica y con oportunidad de
   que ambas copias se desincronizaran al corregir un bug en una sola. Ahora vive en un
   solo lugar (`TransportationProblem.GetBalanced()`) y los tres algoritmos lo comparten.
3. **Validación de negativos consistente.** Se centralizó en `EditableValue.TryGetValue()`
   y `TryBuildProblem()`, evitando el patrón repetido de `if (isNaN...) ... if (v<0) ...`
   en cada función.

No se modificó el criterio de selección de "menor costo" (primer mínimo encontrado, sin
tie-break especial) para no alterar resultados que el estudiante ya conoce de la versión
web; se documentó explícitamente la regla de empate para que sea reproducible.

## Guardado de proyectos y exportación a PDF

- **Guardar**: `ProjectFileService` serializa un `TransportationProject` (nombre, fecha,
  dimensiones, matriz de costos, ofertas, demandas, método usado, costo total) a JSON y
  abre el diálogo nativo **"Guardar como"** del sistema (`FileSaver` de
  `CommunityToolkit.Maui`) para que el usuario elija dónde guardarlo. Si cancela el
  diálogo, no pasa nada (no es un error); si guarda, se confirma con un mensaje.
- **Compartir**: si el proyecto no se guardó todavía en esta sesión, primero dispara
  "Guardar" y después abre el panel nativo de compartir del sistema (`Share.Default`)
  con el archivo ya guardado.
- **Abrir**: usa `FilePicker` (filtrado a `.json`) para elegir el archivo y valida su
  estructura antes de cargarlo (dimensiones coherentes, sin negativos), para no romper
  la app con un archivo corrupto o editado a mano.
- **Exportar a PDF**: `PdfExportService` genera un informe con **QuestPDF** (librería
  100% .NET, multiplataforma, con licencia Community gratuita para uso académico/no
  comercial) que incluye nombre del proyecto, fecha, método, matriz de costos original,
  estado de balanceo, elemento ficticio si lo hubo, tabla de solución y el cálculo del
  costo total término a término, y lo abre directamente en el panel nativo de compartir
  (`Share.Default`) — esto ya se probó y funciona.

## Paquetes NuGet utilizados y por qué

| Paquete | Uso |
|---|---|
| `CommunityToolkit.Mvvm` | `[ObservableProperty]`/`[RelayCommand]` (menos código repetitivo en los ViewModels) y `WeakReferenceMessenger` para la comunicación ViewModel→Vista al reconstruir la grilla dinámica. |
| `CommunityToolkit.Maui` | `FileSaver`: diálogo nativo "Guardar como" multiplataforma para el botón Guardar Proyecto. Requiere `.UseMauiCommunityToolkit()` en `MauiProgram.cs`. |
| `QuestPDF` | Generación de PDF. Elegida por ser .NET puro (sin dependencias nativas problemáticas en MAUI), con buen mantenimiento activo y licencia Community gratuita para proyectos no comerciales/académicos. |
| `System.Text.Json` | Serializar/deserializar los archivos de proyecto (.transp.json). |
| `xunit` + `xunit.runner.visualstudio` + `Microsoft.NET.Test.Sdk` | Pruebas unitarias de los algoritmos (en `TransporteMAUI.Tests`). |

## Pruebas incluidas

En `TransporteMAUI.Tests` (ver también el punto "Pruebas" del pedido original):

- `BalancingTests`: problema balanceado, oferta > demanda, demanda > oferta, verifica que
  el costo del elemento ficticio sea siempre 0.
- `NorthwestCornerMethodTests`: caso balanceado, matriz 1×1, valores en cero, ficticio,
  matriz más grande (4×5).
- `LeastCostMethodTests`: caso balanceado, empate de costos (regla de desempate), ficticio,
  caso donde fila y columna se satisfacen al mismo tiempo (degenerado).
- `VogelMethodTests`: caso balanceado, comparación de costo contra Esquina Noroeste (Vogel
  debería igualar o mejorar), empate de penalizaciones, ficticio, matriz más grande, caso
  con una sola fila/columna activa.

Todas las pruebas usan un helper compartido (`SolutionAssertions.AssertFeasible`) que
verifica que la solución respete exactamente las ofertas y demandas balanceadas, y que el
costo total coincida con la suma manual de cantidad × costo.

### ViewModels testeables (sin necesitar una app MAUI corriendo)

Los ViewModels (`MainViewModel`, `NewProblemViewModel`, `SolutionViewModel`) viven en
**TransporteMAUI.Core**, igual que los algoritmos. Para lograrlo sin arrastrar una
dependencia de MAUI Controls a esa librería, no llaman directo a `Shell.Current` o
`Application.Current`: dependen de interfaces (`Services/I*.cs` en Core) que se
implementan de dos formas distintas:

- **En la app real** (`TransporteMAUI/Services/`): `ShellNavigationService`,
  `MauiDialogService`, `AppLifecycleService`, más `ProjectFileService`/`PdfExportService`
  (que ya existían) implementando `IProjectFileService`/`IPdfExportService`.
- **En los tests** (`TransporteMAUI.Tests/Fakes/`): dobles de prueba que no navegan ni
  muestran diálogos de verdad, solo registran qué se les pidió, para poder verificarlo.

Esto es lo que permitió agregar:

- `MainViewModelTests`: incluye como test de regresión el bug real de "los botones de
  Guardar/Compartir/Exportar quedan deshabilitados para siempre" (dependían de una
  propiedad calculada sin que nadie le avisara al comando que se reevalúe), y prueba el
  flujo nuevo de "abrir un proyecto ya resuelto lo vuelve a resolver solo y muestra la
  solución directamente" en vez de obligar a repetir Validar/Resolver a mano.
- `NewProblemViewModelTests`: mismo tipo de test de regresión para el botón "Resolver con
  este método" (el bug real que encontraron probando la app), más balanceo/ficticio y que
  `Solve()` deje todo listo en el proyecto compartido.
- `SolutionViewModelTests`: construcción de la tabla, y que **exportar a PDF use las
  etiquetas de fila/columna tal como están en pantalla** (si el usuario renombró "O1" a
  un nombre propio, el PDF ahora respeta ese nombre en vez de siempre imprimir "O1").

## Qué falta / próximos pasos sugeridos

**Tema visual (dorado/negro oscuro)**: la app pasó de un look claro estilo Office a un
tema oscuro dorado/negro (inspirado en Visual Studio dark + una paleta cálida), con:
- Tipografías: **Instrument Sans** (Semibold) para títulos/encabezados, **Geist** para el
  resto del texto. Los `.ttf` ya están en `Resources/Fonts/` y registrados en
  `MauiProgram.cs` — no hace falta ninguna acción adicional.
- Toda la paleta vive en `Resources/Styles/Colors.xaml` (superficies, dorados, texto,
  bordes) y `Resources/Styles/Styles.xaml` (estilos que la consumen). Para retocar el
  tema alcanza con cambiar los valores ahí, no hace falta tocar las vistas.
- Pantalla de bienvenida (`Views/SplashPage.xaml`) con el degradé dorado/negro
  (`GoldHeroGradient`), se muestra 1.4s al arrancar y navega sola a Inicio.
- El mismo degradé, en una versión más sutil y siempre oscura (`GoldTitleBarGradient`),
  se usa en la barra de título de cada pantalla.

**Historial de correcciones post-entrega inicial** (por si es útil para el informe):
- Se migró todo el proyecto de `net8.0` a **`net10.0`** (.NET MAUI 8 ya no tiene soporte
  desde mayo de 2025; .NET 10 es la versión LTS vigente). Esto requiere Visual Studio 2026.
- Faltaba por completo la carpeta **`Platforms/`**, que todo proyecto .NET MAUI necesita
  para arrancar en cada sistema operativo (en Windows, el `App.xaml` de WinUI, el
  `Package.appxmanifest`, el `app.manifest` y los íconos; en Android, `MainActivity`,
  `MainApplication` y el `AndroidManifest.xml`; en iOS/MacCatalyst, `AppDelegate` y
  `Info.plist`). Sin esto, el build "compilaba vacío" y no generaba el `.exe`, que fue el
  primer error que apareció al abrir el proyecto. Ya está agregada con placeholders
  mínimos (íconos de un solo color) — antes de publicar conviene reemplazarlos por un
  ícono real.

Siguiendo el orden de prioridades del pedido original, esto es lo que quedó como base
sólida (Prioridad 1 y 2 completas) y lo que se deja planteado para continuar (Prioridad 3
y 4, ya con la arquitectura lista para no requerir cambios grandes):

- **Íconos y splash**: se incluyeron placeholders SVG mínimos en `Resources/Images` para
  que el proyecto compile; conviene reemplazarlos por un ícono propio antes de publicar.
- Verificar en Visual Studio los nombres/versiones exactas de paquetes NuGet (pueden haber
  versiones más nuevas disponibles al momento de compilar) y correr `dotnet build` /
  `dotnet test` para confirmar que todo compila limpio.
